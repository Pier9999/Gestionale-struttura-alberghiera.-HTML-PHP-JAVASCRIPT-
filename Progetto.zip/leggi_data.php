<?php
include_once "libreria.php";
$conn = connetti_db();

if ($conn) {
    $data = array();
    $query = "SELECT * FROM data";
    
    $result = mysqli_query($conn, $query);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        
        echo json_encode($data);
    } else {
        echo "Errore nell'esecuzione della query: " . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    echo "Connessione al database fallita";
}
?>
