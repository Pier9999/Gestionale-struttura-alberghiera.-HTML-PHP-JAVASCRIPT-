<?php
// Dati di connessione al database
include_once "../libreria.php";

// Crea connessione
$conn = connetti_db();

// Verifica connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Anno da analizzare
$anno = 2024;

// Query SQL per ottenere la somma degli importi per ogni mese del dato anno
$sql = "
    SELECT 
        MONTH(DataFattura) AS mese, 
        SUM(Importo) AS somma_importo
    FROM 
        fatture
    WHERE 
        YEAR(DataFattura) = ?
    GROUP BY 
        MONTH(DataFattura)
    ORDER BY 
        mese
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $anno);
$stmt->execute();
$result = $stmt->get_result();

// Gestione dei risultati
$somme_mensili = array();
while ($row = $result->fetch_assoc()) {
    $somme_mensili[intval($row['mese'])] = floatval($row['somma_importo']);
}

// Chiudo la connessione
$stmt->close();
$conn->close();

// Array dei nomi dei mesi
$mesi_nomi = [
    1 => "Gennaio", 2 => "Febbraio", 3 => "Marzo", 
    4 => "Aprile", 5 => "Maggio", 6 => "Giugno", 
    7 => "Luglio", 8 => "Agosto", 9 => "Settembre", 
    10 => "Ottobre", 11 => "Novembre", 12 => "Dicembre"
];
// Creazione della tabella HTML
echo '<table border="1">';
echo '<tr>';

// Contatore per tenere traccia del numero di celle
$cell_count = 0;

for ($mese = 1; $mese <= 12; $mese++) {
    if ($cell_count % 4 == 0 && $cell_count != 0) {
        echo '</tr><tr>';
    }
    $nome_mese = $mesi_nomi[$mese];
    $somma_importo = isset($somme_mensili[$mese]) ? $somme_mensili[$mese] : 0;
    echo "<td><strong>$nome_mese</strong><br>Somma Importi: $somma_importo €</td>";
    $cell_count++;
}

// Chiudo la riga e la tabella
echo '</tr>';
echo '</table>';
?>
