document.getElementById("btnAvanti").addEventListener("click", function() {
    var ajaxLeggi = new XMLHttpRequest();
    var method = "GET";
    var url = "../leggi_data.php"; // Specifico il nome del file PHP da richiamare
    var asynchronous = true;
    var nuovaData;

    ajaxLeggi.open(method, url, asynchronous); // Metodo GET per richiedere dati al server PHP in modo asincrono

    ajaxLeggi.send(); // mando la richiesta
    ajaxLeggi.onreadystatechange = function() // attende la risposta da data.php
    {
        if (this.readyState == 4 && this.status == 200) {
            // converto i dati json in array
            var dati = JSON.parse(this.responseText);
            console.log(dati); // per il debugging
            var dataCorrente = new Date(dati[0].DataCorrente);

            // Incremento la data di 12 giorni
            dataCorrente.setDate(dataCorrente.getDate() + 12);

            // Formatto la nuova data nel formato 'YYYY-MM-DD'
            nuovaData = dataCorrente.toISOString().split('T')[0];
            aggiornaData(nuovaData);
            
        }
    }

});

document.getElementById("btnIndietro").addEventListener("click", function() {
    var ajaxLeggi = new XMLHttpRequest();
    var method = "GET";
    var url = "../leggi_data.php"; // Specifico il nome del file PHP da richiamare
    var asynchronous = true;
    var nuovaData;

    ajaxLeggi.open(method, url, asynchronous); // Metodo GET per richiedere dati al server PHP in modo asincrono

    ajaxLeggi.send(); // mando la richiesta
    ajaxLeggi.onreadystatechange = function() // attendo la risposta da data.php
    {
        if (this.readyState == 4 && this.status == 200) {
            // converto i dati json in array
            var dati = JSON.parse(this.responseText);
            console.log(dati); // per il debugging
            var dataCorrente = new Date(dati[0].DataCorrente);

            // Incremento la data di un giorno
            dataCorrente.setDate(dataCorrente.getDate() - 12);

            // Formatto la nuova data nel formato 'YYYY-MM-DD'
            nuovaData = dataCorrente.toISOString().split('T')[0];
            aggiornaData(nuovaData);
        }
    }

});

function aggiornaData(nuovaData) {
    console.log("Sono entrato nella funzione");
    var ajaxAggiornaData = new XMLHttpRequest();
    var methodAggiornaData = "GET";
    var urlAggiornaData = "../update_data.php?data=" + encodeURIComponent(nuovaData); // Codifico correttamente la nuova data
    var asynchronousAggiornaData = true;

    ajaxAggiornaData.open(methodAggiornaData, urlAggiornaData, asynchronousAggiornaData);
    ajaxAggiornaData.send();

    ajaxAggiornaData.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log("Nuova data aggiornata nel database con successo.");
            location.reload();
        }
    }
}