<?php
session_start();

// Verifico se l'utente è autenticato
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.html"); // Reindirizzo alla pagina di login se non autenticato
    exit();
}
?>


<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cà Isabella</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
  <?php include_once "../barranav.html";
  include_once "../libreria.php";
  ?>
  <div class="container my-5 text-center">
    <p class="lead">
    <h2>Sezione principale</h2>
    </p><br>
    <div class="form-group" style="float: right;">
      <label class="active" for="dateStandard">Ricerca per data</label>
      <input type="date" id="dateStandard" name="dateStandard" onchange="aggiornaData(this.value)">
    </div>
    <table class="table table-bordered border-primary">
      <?php
      $NumGiorni = 12;

      $res = risultato();
      $DataIniziale = date("Y-m-d");
      if ($res->num_rows == 0) {
        inserisci($DataIniziale);
      } else {
        $row = $res->fetch_assoc();
        $DataIniziale = $row['DataCorrente'];
      }

      CreaIntestazione($DataIniziale, $NumGiorni);
      RigaVuota($NumGiorni);
      RiempiTabella($DataIniziale, 12);
      echo '</table>';
      echo '</div>'
      ?>
      <div class="container">
        <div class="row justify-content-end">
          <div class="col">
            <button type="button" class="btn btn-outline-primary" id="btnIndietro" name="btnIndietro">Indietro</button>
          </div>
          <div class="col-md-6 offset-md-3">
            <a href="../camere/camere_main.php"><button type="button" class="btn btn-outline-primary">Camere</button></a>
            <a href="../agenzie/agenzie_main.php"><button type="button" class="btn btn-outline-primary">Agenzie</button></a>
            <a href="../clienti/clienti_main.php"><button type="button" class="btn btn-outline-primary">Clienti</button></a>
          </div>
          <div class="col-auto">
            <button type="button" class="btn btn-outline-primary" id="btnAvanti" name="btnAvanti">Avanti</button>
          </div>
        </div>
      </div>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
      <script src="../js/aggiornaData.js"></script>
</body>

</html>