<table id="myTable" class="table table-bordered border-primary">

    <thead>
        <th>Nome Agenzia</th>
        <th>Commissione</th>
        <th>Colore</th>
    </thead>
    </div>
    <tbody>

        <?php
        include "../libreria.php";
        $QueryCamere = "SELECT * FROM agenzie";
        $res = eseguiQuery($QueryCamere);

        while ($row = $res->fetch_array()) {
            echo '
        <tr>
        <td>' . $row['NomeAgenzia'] . '</td>
        <td>' . $row['Commissione'] . '</td>
        <td>' . $row['Colore'] . '</td>
        </tr>
        ';
        } ?>
    </tbody>
</table>

<div class="row justify-content-center text-center">
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnIns" name="btnIns">Nuova</button>
    </div>
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnMod" name="btnMod">Modifica</button>
    </div>
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnEl" name="btnEl" disabled>Cancella</button>
    </div>
</div>