

<h3>Nuova agenzia inserimento:</h3>
<div id="selectedRowData"></div>
<form class="needs-validation" id="myForm" action="inserisci_agenzia.php" method="POST">
    <br>
    <div>
        <div class="form-group">
            <label class="active" for="NomeAgenzia">Nome agenzia</label>
            <input type="text" class="form-control" id="NomeAgenzia" name="NomeAgenzia" placeholder="Nome dell'agenzia" required>
        </div>

        <div class="col-md-6">
            <div class="form-group mt-1">
                <label for="inputNumber4" class="input-number-label active">Percentuale Commissione</label>
                <div class="input-group input-number input-number-percentage">
                    <span class="input-group-text fw-semibold">%</span>
                    <input type="number" class="form-control" data-bs-input id="Commissione" name="Commissione" value="" min="0" max="15" step="any" />
                    <span class="input-group-text align-buttons flex-column">

                    </span>
                </div>
            </div>
        </div>
        <br>
        <div class="col-md-6">
            <div class="form-group mt-2">
                <div class="select-wrapper">
                    <label for="defaultSelect">Colore</label>
                    <select id="Colore" name="Colore">
                        <option selected="" value="Blu">Blu</option>
                        <option value="Arancio">Arancio</option>
                        <option value="Grigio">Grigio</option>
                        <option value="Nero">Nero</option>
                        <option value="Verde">Verde</option>
                        <option value="Rosso">Rosso</option>
                        <option value="Giallo">Grigio</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
    <br>
    <button type="submit" class="btn btn-primary">Inserisci</button>
</form>