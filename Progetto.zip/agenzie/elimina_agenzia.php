<?php
include "../libreria.php";

// Connessione al database usando mysqli
$conn = connetti_db();

// Controllo della connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Recupero e sanificazione dei dati di input
$NomeAgenzia = sanitize_input($_POST['NomeAgenzia']);


// Validazione dei dati
if ($NomeAgenzia) {
    // Preparazione della query
    $stmt = $conn->prepare("DELETE FROM agenzie WHERE NomeAgenzia = ?");
    
    if ($stmt === false) {
        die("Preparazione della query fallita: " . $conn->error);
    }

    // Binding dei parametri
    $stmt->bind_param("s", $NomeAgenzia);

    // Esecuzione della query
    if ($stmt->execute()) {
        // Reindirizzamento
        header("Location: agenzie_main.php");
        exit();
    } else {
            die("Esecuzione della query fallita: " . $stmt->error);
        }
    

    // Chiusura dello statement
    $stmt->close();
} else {
    die("Dati non validi.");
}

// Chiusura della connessione
$conn->close();
?>