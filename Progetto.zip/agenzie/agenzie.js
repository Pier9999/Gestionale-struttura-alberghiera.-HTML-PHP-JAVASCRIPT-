document.addEventListener("DOMContentLoaded", function() {
    const contentContainer = document.getElementById("contentContainer");
    const btnInserisci = document.getElementById("btnIns");
    const btnModifica = document.getElementById("btnMod");
    const btnElimina = document.getElementById("btnEl");

    // Codice per gestire il click sui bottoni e il caricamento del contenuto HTML
    btnInserisci.addEventListener("click", function() {
        loadContent("agenzia_inserimento.php");
    });

    btnModifica.addEventListener("click", function() {
        loadContent("agenzia_modifica.html");
    });

    btnElimina.addEventListener("click", function() {
        loadContent("agenzia_elimina.html");
    });

    function loadContent(filename) {
        fetch(filename)
            .then(response => response.text())
            .then(data => {
                contentContainer.innerHTML = data;
            })
            .catch(error => {
                console.error('Si è verificato un errore durante il caricamento del contenuto:', error);
            });
    }

    // Codice per gestire il click sulle righe della tabella e il riempimento del form
    var table = document.getElementById("myTable");
    var rows = table.getElementsByTagName("tr");

    for (var i = 0; i < rows.length; i++) {
        rows[i].addEventListener("click", function() {
            var cells = this.getElementsByTagName("td");
            var rowData = [];
            for (var j = 0; j < cells.length; j++) {
                rowData.push(cells[j].innerHTML);
            }
            fillForm(rowData);
        });
    }

    function fillForm(rowData) {
        
        document.getElementById("NomeAgenzia").value = rowData[0];
        document.getElementById("Commissione").value = rowData[1];
        document.getElementById("Colore").value = rowData[2];
    }
});
