<?php
include "../libreria.php";

// Connessione al database usando mysqli
$conn = connetti_db();

// Controllo della connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Recupero e sanificazione dei dati di input
$NomeAgenzia = sanitize_input($_POST['NomeAgenzia']);
$Commissione = sanitize_int($_POST['Commissione']);
$Colore = sanitize_input($_POST['Colore']);

// Validazione dei dati
if ($NomeAgenzia) {
    try {
        // Preparazione della query
        $stmt = $conn->prepare("INSERT INTO agenzie (NomeAgenzia, Commissione, Colore) VALUES (?, ?, ?)");
        
        if ($stmt === false) {
            die("Preparazione della query fallita: " . $conn->error);
        }

        // Binding dei parametri
        $stmt->bind_param("sis", $NomeAgenzia, $Commissione, $Colore);

        // Esecuzione della query
        if ($stmt->execute()) {
            // Reindirizzamento
            header("Location: agenzie_main.php");
            exit();
        }
    } catch (mysqli_sql_exception $e) {
        // Controlla se l'errore è dovuto a una duplicazione della chiave primaria
        if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
            echo "Errore: il nome dell'agenzia '$NomeAgenzia' esiste già.";
        } else {
            die("Esecuzione della query fallita: " . $e->getMessage());
        }
    }

    // Chiusura dello statement
    $stmt->close();
} else {
    die("Dati non validi.");
}

// Chiusura della connessione
$conn->close();
?>

