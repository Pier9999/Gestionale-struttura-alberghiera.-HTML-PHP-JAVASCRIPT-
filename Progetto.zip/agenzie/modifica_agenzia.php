<?php
include "../libreria.php";

$conn = connetti_db();

// Controllo della connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Recupero e sanificazione dei dati di input
$nomeAgenzia = sanitize_input($_POST['NomeAgenzia']);
$commissione = sanitize_int($_POST['Commissione']);
$colore = sanitize_input($_POST['Colore']);

// Validazione dei dati
if ($nomeAgenzia && $commissione !== false && in_array($colore, ['Arancio', 'Giallo', 'Blu', 'Verde', 'Rosso', 'Grigio', 'Nero'])) {
    // Preparazione della query
    $stmt = $conn->prepare("UPDATE agenzie SET Commissione = ?, Colore = ? WHERE NomeAgenzia = ?");
    
    if ($stmt === false) {
        die("Preparazione della query fallita: " . $conn->error);
    }

    // Binding dei parametri
    $stmt->bind_param("iss", $commissione, $colore, $nomeAgenzia);

    // Esecuzione della query
    if ($stmt->execute()) {
        // Reindirizzamento
        header("Location: agenzie_main.php");
        exit();
    } else {
        die("Esecuzione della query fallita: " . $stmt->error);
    }

    // Chiusura dello statement
    $stmt->close();
} else {
    die("Dati non validi.");
}

// Chiusura della connessione
$conn->close();
?>
