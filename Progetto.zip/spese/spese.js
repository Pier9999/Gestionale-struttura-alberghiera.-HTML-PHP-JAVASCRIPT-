document.addEventListener("DOMContentLoaded", function () {
    const contentContainer = document.getElementById("contentContainer");
    const btnInserisci = document.getElementById("btnIns");
    const btnModifica = document.getElementById("btnMod");
    const btnElimina = document.getElementById("btnEl");

    // Codice per gestire il click sui bottoni e il caricamento del contenuto HTML
    btnInserisci.addEventListener('click', function () {
        loadContent('spesa_inserisci.php', function () {
            popolaFormInserisci();
        });
    });

    btnModifica.addEventListener("click", function () {
        loadContent("spesa_modifica.php", function () {

        });
    });

    btnElimina.addEventListener("click", function () {
        loadContent("spesa_elimina.php", function () {

        });
    });


    function loadContent(filename, callback) {
        fetch(filename)
            .then(response => response.text())
            .then(data => {
                contentContainer.innerHTML = data;
                callback();
            })
            .catch(error => {
                console.error('Si è verificato un errore durante il caricamento del contenuto:', error);
            });
    }



    // Codice per gestire il click sulle righe della tabella e il riempimento del form
    var table = document.getElementById("TabellaSpese");
    var rows = table.getElementsByTagName("tr");

    for (var i = 0; i < rows.length; i++) {
        rows[i].addEventListener("click", function () {
            var cells = this.getElementsByTagName("td");
            var rowData = [];
            for (var j = 0; j < cells.length; j++) {
                rowData.push(cells[j].innerHTML);
            }
            fillForm(rowData);
        });
    }

});

function convertiFormatoData(data) {
    // Divido la data in parti usando il separatore '/'
    var partiData = data.split('-');

    // Estraggo giorno, mese e anno
    var anno = partiData[0];
    var mese = partiData[1];
    var giorno = partiData[2];

    // Costruisco la data nel nuovo formato
    var nuovaData = giorno + '-' + mese + '-' + anno;


    return nuovaData;
}


// inserisco Cognome e Nome nell'intestazione
document.addEventListener("DOMContentLoaded", function () {
    // Recupero le variabili dal localStorage
    var rigaHTML = localStorage.getItem("rigaDati");

    var Nome = rigaHTML.split(", ")[3] + " " + rigaHTML.split(", ")[2];
    
    var Arrivo = rigaHTML.split(", ")[5];
    var Partenza = rigaHTML.split(", ")[6];

    Arrivo = convertiFormatoData(Arrivo);
    Partenza = convertiFormatoData(Partenza);
    // Seleziono l'elemento <h2> per la sezione spese
    var speseTitle = document.getElementById("intestazione");

    // Aggiorno il contenuto dell'elemento <h2> con le variabili
    if (Nome) {
        speseTitle.textContent = "Spese extra per il Sig. " + Nome + " dal " + Arrivo + " al " + Partenza;
    }
});

function popolaFormInserisci() {
    var rigaHTML = localStorage.getItem("rigaDati");
    if (rigaHTML) {
        // Popolo il campo con id "IdPrenotazione" nel form specificato con il valore memorizzato
        var form = document.getElementById('FormInserisci');
        if (form) {
            var idPrenotazioneInput = form.querySelector('#IdPrenotazione');
            if (idPrenotazioneInput) {
                idPrenotazioneInput.value = rigaHTML.split(", ")[1];
            } else {
                console.error('Campo "IdPrenotazione" non trovato nel form.');
            }
        } else {
            console.error('Form con ID specificato non trovato.');
        }
    } else {
        console.error('Nessun dato trovato nel localStorage.');
    }
}

function conferma() {
    // Mostro la finestra di conferma
    var conferma = confirm("Sei sicuro di eliminare la spesa?");

    // Se l'utente conferma, eseguo il submit del form
    if (conferma) {
        return true; // Invio il form
    } else {
        // Altrimenti, non faccio nulla
        console.log("Invio del modulo annullato.");
        return false;
    }
}






