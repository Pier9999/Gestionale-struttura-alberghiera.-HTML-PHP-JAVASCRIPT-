<h3>Modifica spesa:</h3>
<div class="container">
    <div id="selectedRowData"></div>
    <form class="needs-validation" id="myForm" action="modificaSpesa.php" method="POST">
        <?php
        include "formSpesa.php";
        ?>

        <div>
            <button type="submit" class="btn btn-primary">Modifica</button>
        </div>
    </form>
</div>
</div>
<script src="recuperaInfo.js"></script>

