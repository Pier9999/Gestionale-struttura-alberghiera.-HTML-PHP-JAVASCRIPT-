<?php
// Connessione al database
// Creo la connessione
$conn = connetti_db();

// Verifica la connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Ottiengo l'ID della prenotazione dalla richiesta AJAX e sanitizzalo
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Preparo e eseguo l'istruzione SQL utilizzando istruzioni preparate
$query = "SELECT * FROM spese WHERE PrenotazioneId = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();

// Ottiengo il risultato della query
$result = $stmt->get_result();

// Gestisco il risultato 
if ($result->num_rows > 0) {
    // Genero un array associativo dei dati della tupla
    $row = $result->fetch_assoc();

    // Restituisco i dati come JSON
    header('Content-Type: application/json');
    echo json_encode($row);
} else {
    // Se la tupla non è stata trovata, restituisco un messaggio di errore
    echo json_encode(array("error" => "Nessuna tupla trovata con l'ID fornito"));
}

// Chiudo la connessione al database
$conn->close();
?>