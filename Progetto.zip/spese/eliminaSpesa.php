<?php
include "../libreria.php";

// Verifico se sono stati ricevuti tutti i parametri necessari
if (isset($_POST['IdSpesa'])) {
    // Validazione dei dati in ingresso
    $IdSpesa = intval(sanitize_int($_POST['IdSpesa'])); // Assicuro che IdSpesa sia un intero valido

    // Utilizzo di una dichiarazione preparata per eseguire la query
    $sql = "DELETE FROM spese WHERE IdSpesa = ?";


    $conn = connetti_db();
    if ($conn === false) {
        die("Connessione al database fallita.");
    }
    
    $stmt = $conn->prepare($sql);

    // Verifico la preparazione della dichiarazione
    if ($stmt === false) {
        die("Preparazione della dichiarazione SQL fallita: " . $conn->error);
    }
    // Associo il parametro alla dichiarazione preparata
    $stmt->bind_param("i", $IdSpesa);

    // Eseguo la query preparata
    if ($stmt->execute()) {
        // Reindirizzo l'utente alla pagina principale delle spese dopo aver eliminato la spesa
        header("Location: spese_main.php");
        exit();
    } else {
        // Gestisco eventuali errori nell'esecuzione della query
        echo "Si è verificato un errore durante l'eliminazione della spesa.";
    }
} else {
    // Se i parametri necessari non sono stati forniti, gestisco il caso adeguatamente
    echo "Parametri mancanti per l'eliminazione della spesa.";
}
