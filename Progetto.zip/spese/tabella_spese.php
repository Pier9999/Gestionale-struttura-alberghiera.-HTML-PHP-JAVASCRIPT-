<h5>Elenco spese extra</h5>
<div class="table responsive">
    <table id="TabellaSpese" class="table table-bordered border-primary">
        <thead>
            <th>Id Pren.</th>
            <th>Id Spesa</th>
            <th>Voce spesa</th>
            <th>Importo</th>
        </thead>
        <tbody id="tableBody">

        
        </tbody>
    </table>
</div>

<div class="row justify-content-center text-center">
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnIns" name="btnInserisci">Nuova</button>
    </div>
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnMod" name="btnModifica">Modifica</button>
    </div>
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnEl" name="btnElimina">Cancella</button>
    </div>
</div>
<br>