<h3>Cancella spesa:</h3>
<div class="container">
    <div id="selectedRowData"></div>
    <form class="needs-validation" id="myForm" action="eliminaSpesa.php" method="POST" onsubmit="return conferma()">
        <?php
        include "formSpesa.php";
        ?>

        <div>
            <button type="submit" class="btn btn-primary">Elimina</button>
        </div>
    </form>
</div>
<script src="recuperaInfo.js"></script>