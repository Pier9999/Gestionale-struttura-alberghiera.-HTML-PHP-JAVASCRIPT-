<h3>Nuova spesa inserimento:</h3>
<div class="container">
    <div id="selectedRowData"></div>
    <form class="needs-validation" id="FormInserisci" action="inserisciSpesa.php" method="POST">
        <?php
        include "formSpesa.php";
        ?>

        <div>
            <button type="submit" class="btn btn-primary">Inserisci</button>
        </div>
    </form>
</div>
</div>
<script src="recuperaInfo.js"></script>