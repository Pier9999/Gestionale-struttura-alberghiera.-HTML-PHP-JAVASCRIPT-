// lgge dal localStorage esegue una query e popola la tabella e aggiunge un listener ad ogni riga

document.addEventListener("DOMContentLoaded", function () {
    var rigaHTML = localStorage.getItem("rigaDati");

    if (rigaHTML !== null) {

        var IdPrenotazione = rigaHTML.split(", ")[1];

        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'querySpese.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    console.log('Risposta ricevuta: ' + xhr.responseText);
                    var data = JSON.parse(xhr.responseText);
                    var tableBody = document.getElementById('tableBody');

                    // Pulisco la tabella prima di riempirla di nuovo
                    tableBody.innerHTML = '';

                    if (data.length > 0) {
                        data.forEach(row => {
                            var newRow = document.createElement('tr');
                            Object.values(row).forEach(value => {
                                var newCell = document.createElement('td');
                                newCell.textContent = value;
                                newRow.appendChild(newCell);
                            });
                            tableBody.appendChild(newRow);
                        });

                        // Aggiungo gli event listener alle righe
                        addRowListeners();
                    } else {
                        // Se non ci sono dati, non faccio nulla
                        console.log('Nessun dato trovato.');
                    }
                } else {
                    console.error('Si è verificato un errore:', xhr.status);
                }
            }
        };

        var params = 'IdPrenotazione=' + IdPrenotazione;
        xhr.send(params);
    } else {
        alert("No data found in localStorage under 'rigaDati'");
    }
});


// popolo il form
function fillForm(rowData) {
    var form = document.getElementById('myForm');
    if (form) {
        var idPrenotazione = form.querySelector('#IdPrenotazione');
        var idSpesa = form.querySelector('#IdSpesa');
        var Spesa = form.querySelector('#Spesa');
        var Importo = form.querySelector('#Importo');

        idPrenotazione.value = rowData[0];
        idSpesa.value = rowData[1];
        Spesa.value = rowData[2];
        Importo.value = rowData[3];
    }
}


// Aggiungo dei Listener ad ogni riga della tabella
function addRowListeners() {
    var rows = document.querySelectorAll('#tableBody tr');  // Seleziono tutte le righe della tabella
    rows.forEach(row => {
        row.addEventListener('click', function () {
            var cells = this.getElementsByTagName('td');
            var rowData = [];
            for (var j = 0; j < cells.length; j++) {
                rowData.push(cells[j].innerHTML);
            }
            fillForm(rowData); // Passo il secondo valore della riga
        });
    });
}

