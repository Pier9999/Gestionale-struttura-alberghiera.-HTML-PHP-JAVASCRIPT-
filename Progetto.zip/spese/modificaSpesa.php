<?php
include "../libreria.php";

$conn = connetti_db();

if (isset($_POST['IdSpesa'], $_POST['Spesa'], $_POST['Importo'])) {
    // Ottiengo i dati POST
    $IdSpesa = sanitize_int($_POST['IdSpesa']);
    $Spesa = sanitize_input($_POST['Spesa']);
    $Importo = sanitize_input($_POST['Importo']);

    // Preparazione dello statement SQL
    $sql = "UPDATE spese SET Descrizione = ?, Importo = ? WHERE IdSpesa = ?";
    $stmt = mysqli_prepare($conn, $sql);

    // Associo i parametri
    mysqli_stmt_bind_param($stmt, "sdi", $Spesa, $Importo, $IdSpesa);

    // Eseguo lo statement
    mysqli_stmt_execute($stmt);
}

header("Location: spese_main.php");
exit();
?>

