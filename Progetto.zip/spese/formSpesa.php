<div class="col-md-6">
    <div class="form-group mt-1">
        
        <input type="hidden" id="IdPrenotazione" name="IdPrenotazione">
    </div>
</div>

<div class="col-md-6">
    <div class="form-group mt-1">
        
        <input type="hidden" id="IdSpesa" name="IdSpesa">
    </div>
</div>

<div class="col-md-6">
    <div class="form-group mt-1">
        <label for="defaultSelect">Spesa</label>
        <input type=" text" class="form-control text-right" id="Spesa" name="Spesa" placeholder="Voce della spesa" required>
    </div>
</div>


<div class="col-md-6">
    <div class="form-group mt-1">
        <label for="defaultSelect">Importo</label>
        <input type=" text" class="form-control text-right" id="Importo" name="Importo" placeholder="Costo" required>
    </div>
</div>

<br>