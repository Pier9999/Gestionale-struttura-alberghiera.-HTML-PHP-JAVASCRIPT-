<?php
include "../libreria.php";

$conn = connetti_db();
// Verifico se i dati POST sono stati inviati
if(isset($_POST['IdPrenotazione'], $_POST['Spesa'], $_POST['Importo'])) {
    // Sanifico i dati POST
    $PrenId = sanitize_int($_POST['IdPrenotazione']);
    $Spesa = sanitize_input($_POST['Spesa']);
    $Importo = sanitize_input($_POST['Importo']);

    // Preparo e eseguo l'istruzione SQL utilizzando istruzioni preparate
    $sql = "INSERT INTO spese (Descrizione, Importo, PrenotazioneId) VALUES(?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, 'sdi', $Spesa, $Importo, $PrenId);
    mysqli_stmt_execute($stmt);

    // Controllo se la query è stata eseguita correttamente
    if(mysqli_stmt_affected_rows($stmt) > 0) {
        // Reindirizzo dopo l'inserimento
        header("Location: spese_main.php");
        exit();
    } else {
        // Gestisco eventuali errori durante l'inserimento dei dati
        echo "Si è verificato un errore durante l'inserimento dei dati.";
    }
} else {
    // Gestisco il caso in cui i dati POST non siano stati inviati
    echo "Dati mancanti.";
}
?>
