<?php
// Connessione al database
include_once "libreria.php";
$conn = connetti_db();

if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Hash della password
$password_plain = '6q4H$j0u';
$password_hash = password_hash($password_plain, PASSWORD_BCRYPT);

// Inserimento dell'utente
$sql = $conn->prepare("INSERT INTO utenti (login, password) VALUES (?, ?)");
$sql->bind_param("ss", $login, $password_hash);

$login = 'Pier';
$sql->execute();

echo "Nuovo record creato con successo";

$sql->close();
$conn->close();
?>