
document.getElementById("myForm").addEventListener("submit", function(event) {
    var inputField = document.getElementById("NomeCamera");
    if (!inputField.value) {
        // Interrompo del submit
        event.preventDefault();
        // Visualizzo un messaggio di errore
        alert("Il campo input è richiesto.");
    }
});

$(document).ready(function() {
    $('#myForm').on('submit', function(event) {
        event.preventDefault();

        $.ajax({
            url: 'inserisci_camera.php', // Cambio con il percorso del tuo script PHP
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    alert(response.message);
                    window.location.href = 'camere_main.php';
                } else {
                    alert(response.message);
                }
            },
            error: function(xhr, status, error) {
                alert('Si è verificato un errore durante l\'invio del form.');
            }
        });
    });
});