
<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Recupero il corpo della richiesta JSON
$json_data = file_get_contents("php://input");

// Decodifico il JSON in un array associativo
$data = json_decode($json_data, true);

// Verifico se i dati sono stati decodificati correttamente
if ($data === null) {
    // Gestisco eventuali errori di decodifica JSON
    die(json_encode(["error" => "Errore nella decodifica JSON dei dati inviati: " . json_last_error_msg()]));
}

// Connessione al database
include "../libreria.php";
$conn = connetti_db();

// Controllo della connessione
if ($conn->connect_error) {
    die(json_encode(["error" => "Connessione al database fallita: " . $conn->connect_error]));
}

// Preparazione della query SQL per prevenire SQL Injection
$stmt = $conn->prepare("SELECT COUNT(*) AS NumOccorrenze FROM camere WHERE NomeCamera = ?");

// Verifico se la preparazione della query è riuscita
if (!$stmt) {
    die(json_encode(["error" => "Errore nella preparazione della query: " . $conn->error]));
}

// Estraggo i dati dalle chiavi dell'array
$nomeCamera = sanitize_input($data['nomeCamera']) ?? null;

// Bind dei parametri alla query preparata
$stmt->bind_param("s", $nomeCamera);

// Esecuzione della query
if (!$stmt->execute()) {
    die(json_encode(["error" => "Errore nell'esecuzione della query: " . $stmt->error]));
}

// Ottengo i risultati dalla query eseguita
$result = $stmt->get_result();
$row = $result->fetch_assoc();

// Estraggo il valore desiderato dall'array
$numOccorrenze = (int) $row['NumOccorrenze'];

// Creazione dell'array dei dati
$data = array("NumOccorrenze" => $numOccorrenze);

// Chiusura dello statement
$stmt->close();

// Chiusura della connessione
$conn->close();

// Ritorno dei dati in formato JSON
echo json_encode($data);
?>
