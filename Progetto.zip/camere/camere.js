document.addEventListener("DOMContentLoaded", function () {
    const formContainer = document.getElementById("formContainer");
    const btnInserisci = document.getElementById("btnIns");
    const btnModifica = document.getElementById("btnMod");
    const btnElimina = document.getElementById("btnEl");

    // Codice per gestire il click sui bottoni e il caricamento del contenuto HTML
    btnInserisci.addEventListener("click", function () {
        loadContent("camere_inserisci.html")
        .then(() => attachFormEvent('InsForm',0))
        .catch(error => console.error('Errore:', error));
    });

    btnModifica.addEventListener("click", function () {
        loadContent("camere_modifica.html")
        .then(() => attachFormEvent('myForm', 1))
        .catch(error => console.error('Errore:', error));
    });

    btnElimina.addEventListener("click", function () {
        loadContent("camere_elimina.html");
    });

    async function loadContent(url) {
        return fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.text();
            })
            .then(html => {
                document.getElementById('formContainer').innerHTML = html;
            });
    }


    // funzione che controlla la se il nome della camera è già presente
    function attachFormEvent(formId, flag) {
        const form = document.getElementById(formId);
        if (form) {
            form.addEventListener('submit', function (event) {
                event.preventDefault();
                try {
                    const formData = new FormData(form);
                    //alert(formData);
                    ControlloNomeCamera(formData)
                        .then(isDisponibile => {
                            if (isDisponibile) {
                                alert("Nome Camera disponibile");
                                // Procedo con la prenotazione
                                InserisciCamera(formData, flag)
                                    .then(isInserita => {
                                        if (isInserita) {
                                            alert("Camera inserita con successo!");
                                            window.location.href = "camere_main.php";
                                        } else {
                                            alert("Non è stato possibile completare l'inserimento della camera'.");
                                        }
                                    });
                            } else {
                                alert("Camera non inserita");
                            }
                        })
                        .catch(error => {
                            console.error('Errore:', error.message);
                            alert('Errore:', error.message);
                        });
                } catch (error) {
                    console.error('Errore durante l\'elaborazione del modulo:', error);
                    alert('Errore durante l\'elaborazione del modulo:', error);
                }
            });
        } else {
            alert('Form non trovato');
        }
    }

    async function ControlloNomeCamera(formData) {
        const nomeCamera = formData.get('NomeCamera');
    
        const datiForm = {
            nomeCamera: nomeCamera
        };
    
        const fileQuery = 'ControllaNomeCamera.php';
    
        try {
            const response = await fetch(fileQuery, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(datiForm),
            });
    
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
    
            const data = await response.json();

            if (data.NumOccorrenze === 0){
                return true;
            }
            else{
                return false;
            }
            
            return data.NumOccorrenze === 0;
    
        } catch (error) {
            console.error('Errore:', error);
            return false; // Aggiungo un ritorno false nel caso di errori
        }
    }
    
    async function InserisciCamera(formData, flag) { 
        const filephp = flag === 0 ? 'inserisci_camera.php' : 'modifica_camera.php';
        try {
            const response = await fetch(filephp, {
                method: 'POST',
                body: formData
            });
    
            if (!response.ok) {
                throw new Error('Errore nella prenotazione della camera');
            }
            const result = await response.json();
            
            return result.success;  // Assumo che la risposta includa un campo booleano "success"
        } catch (error) {
            console.error('Errore durante la prenotazione:', error);
            return false;
        }
    }
    // Codice per gestire il click sulle righe della tabella e il riempimento del form
    var table = document.getElementById("myTable");
    var rows = table.getElementsByTagName("tr");

    for (var i = 0; i < rows.length; i++) {
        rows[i].addEventListener("click", function () {
            var cells = this.getElementsByTagName("td");
            var rowData = [];
            for (var j = 0; j < cells.length; j++) {
                rowData.push(cells[j].innerHTML);
            }
            fillForm(rowData);
        });
    }

    function fillForm(rowData) {
        var form = document.getElementById('myForm');
        if (form) {
            document.getElementById("NomeCamera").value = rowData[0];
            document.getElementById("PostiLetto").value = rowData[1];
            document.getElementById("BagnoInCamera").value = rowData[2];
            document.getElementById("IdCamera").value = rowData[3];

            var BagnoInCameraValue = rowData[2];
            var checkbox = document.getElementById("BagnoInCamera");
            if (BagnoInCameraValue == 1) {
                checkbox.checked = true; // Se il valore è 1, imposto la checkbox spuntata
            } else {
                checkbox.checked = false; // Altrimenti, imposto la checkbox non spuntata
            }
            // Per leggere il valore da un campo di input di tipo "text" con l'ID "NomeCamera":
            var nomeCameraValue = document.getElementById("NomeCamera").value;
            console.log("Valore del campo NomeCamera:", nomeCameraValue);
        }
    }
});



$(document).ready(function () {
    $('#FormCamera').on('submit', function (event) {
        event.preventDefault();

        $.ajax({
            url: 'inserisci_camera.php', // Cambia con il percorso del tuo script PHP
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function (response) {
                if (response.status === 'success') {
                    alert(response.message);
                    window.location.href = 'camere_main.php';
                } else {
                    alert(response.message);
                }
            },
            error: function (xhr, status, error) {
                alert('Si è verificato un errore durante l\'invio del form.');
            }
        });
    });
});

