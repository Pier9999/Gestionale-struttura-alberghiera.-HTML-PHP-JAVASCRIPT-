<table id="myTable" class="table table-bordered border-primary">

    <thead>
        <th>Nome Camera</th>
        <th>N. Posti letto</th>
        <th>Bagno</th>
        <th>Id camera</th>
    </thead>
    </div>
    <tbody>

        <?php
        include "../libreria.php";
        $QueryCamere = "SELECT * FROM camere";
        $res = eseguiQuery($QueryCamere);

        while ($row = $res->fetch_array()) {
            echo '
        <tr>
        <td>' . $row['NomeCamera'] . '</td>
        <td>' . $row['NumPostiLetto'] . '</td>
        <td>' . $row['BagnoInCamera'] . '</td>
        <td>' . $row['IdCamera'] . '</td>
        </tr>
        ';
        } ?>
    </tbody>
</table>

<div class="row justify-content-center text-center">
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnIns" name="btnIns">Nuova camera</button>
    </div>
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnMod" name="btnMod">Modifica</button>
    </div>
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnEl" name="btnEl" disabled>Cancella</button>
    </div>
</div>
<div class="container mt-5">
</div>