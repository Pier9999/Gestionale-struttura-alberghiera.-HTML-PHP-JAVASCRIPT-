
<?php
include "../libreria.php";

// Recupero e sanitizzazione dei dati dal form
$nomeCamera = sanitize_input($_POST['NomeCamera']) ?? '';
$postiLetto = sanitize_int($_POST['PostiLetto']) ?? '';

$bagnoCamera = isset($_POST['BagnoCamera']) ? 1 : 0;
if ($bagnoCamera === 1) {
    $bagnoCamera = sanitize_input($_POST['BagnoCamera']);
}

$id = sanitize_int($_POST['IdCamera']) ?? '';

if ($id) {
    // Apertura della connessione al database 
    $conn = connetti_db();

    if ($conn) {
        // Preparazione della query per la cancellazione
        $stmt = $conn->prepare("DELETE FROM camere WHERE IdCamera = ?");
        if ($stmt) {
            // Binding del parametro
            $stmt->bind_param("i", $id);

            // Esecuzione della query e gestione dell'eventuale errore
            if ($stmt->execute()) {
                // Reindirizzamento in caso di successo
                header("Location: camere_main.php");
                exit();
            } else {
                // Gestione degli errori di esecuzione
                echo "Errore durante l'esecuzione della query: " . $stmt->error;
            }

            // Chiusura dello statement
            $stmt->close();
        } else {
            // Gestione degli errori di preparazione dello statement
            echo "Errore nella preparazione dello statement: " . $conn->error;
        }

        // Chiusura della connessione
        $conn->close();
    } else {
        // Gestione degli errori di connessione
        echo "Errore nella connessione al database";
    }
} else {
    // Gestione dei dati mancanti
    echo "ID della camera non specificato";
}
?>