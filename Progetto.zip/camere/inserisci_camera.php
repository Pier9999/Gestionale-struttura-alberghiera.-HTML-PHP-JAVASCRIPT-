<?php
include_once "../libreria.php";

// Funzione per validare gli input
function validateInput($data)
{
    return htmlspecialchars(stripslashes(trim($data)));
}

$response = array('status' => 'error', 'message' => '');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuper e valido i dati dall'input
    $NomeCamera = sanitize_input($_POST['NomeCamera']);
    $postiLetto = sanitize_int($_POST['PostiLetto']);
    $bagnoCamera = isset($_POST['BagnoInCamera']) ? 1 : 0;

    $id = sanitize_int($_POST['IdCamera']);

    // Controllo se i campi obbligatori sono stati compilati
    if (!empty($NomeCamera) && !empty($postiLetto)) {
        
        $conn = connetti_db();

        // Controllo la connessione
        if ($conn->connect_error) {
            $response['message'] = "Connessione fallita: " . $conn->connect_error;
            echo json_encode($response);
            exit();
        }


        // Preparo la dichiarazione SQL per l'inserimento
        $stmt = $conn->prepare("INSERT INTO camere (NomeCamera, NumPostiLetto, BagnoInCamera) VALUES (?, ?, ?)");
        $stmt->bind_param("sii", $NomeCamera, $postiLetto, $bagnoCamera);

        // Eseguo la query
        if ($stmt->execute()) {
            $response = (['success' => true]);
        } else {
            $response = (['success' => false]);
        }

        // Chiudo la dichiarazione
        $stmt->close();


        // Chiudo la connessione
        $conn->close();
    } else {
        $response = (['success' => false]);
    }

    echo json_encode($response);
    exit();
}
