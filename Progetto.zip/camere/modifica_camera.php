<?php
include "../libreria.php";

$nomeCamera = sanitize_input($_POST['NomeCamera']);
$postiLetto = sanitize_int($_POST['PostiLetto']);
$bagnoInCamera = isset($_POST['BagnoInCamera']) ? 1 : 0;

$id = sanitize_int($_POST['IdCamera']);

// Valido dei dati
if (empty($nomeCamera) || empty($postiLetto) || empty($id)) {
    // Gestisci l'errore (ad esempio, reindirizza a una pagina di errore)
    header("Location: errore.php?messaggio=Dati mancanti");
    exit();
}

// Connessione al database
$conn = connetti_db();

if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Preparazione della query
$stmt = $conn->prepare("UPDATE camere SET NomeCamera = ?, NumPostiLetto = ?, BagnoInCamera = ? WHERE IdCamera = ?");
if ($stmt === false) {
    die("Preparazione della query fallita: " . $conn->error);
}

// Bind dei parametri
$stmt->bind_param('siii', $nomeCamera, $postiLetto, $bagnoInCamera, $id);

// Esecuzione della query
if ($stmt->execute() === false) {
    die("Esecuzione della query fallita: " . $stmt->error);
}

// Chiudo la dichiarazione e la connessione
$stmt->close();
$conn->close();
$response = (['success' => true]);
echo json_encode($response);
exit();
?>