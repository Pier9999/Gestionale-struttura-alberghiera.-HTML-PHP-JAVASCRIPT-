<?php
include "../libreria.php";

$conn = connetti_db();
// Verifico se i dati POST sono stati inviati
if(isset($_POST['NumFattura'], $_POST['dataFattura'], $_POST['Importo'], $_POST['PrenotazioneId'])) {
    // Sanifica i dati POST
    $NumFattura = mysqli_real_escape_string($conn, $_POST['NumFattura']);
    $dataFattura = mysqli_real_escape_string($conn, $_POST['dataFattura']);
    $Importo = mysqli_real_escape_string($conn, $_POST['Importo']);
    $PrenotazioneId = mysqli_real_escape_string($conn, $_POST['PrenotazioneId']);

    // Preparo ed eseguio l'istruzione SQL utilizzando istruzioni preparate
    $sql = "INSERT INTO fatture (NumFattura, DataFattura, Importo, PrenotazioneId) VALUES(?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, 'isdi', $NumFattura, $dataFattura, $Importo, $PrenotazioneId);
    mysqli_stmt_execute($stmt);

    // Controllo se la query è stata eseguita correttamente
    if(mysqli_stmt_affected_rows($stmt) > 0) {
        // Reindirizzo dopo l'inserimento
        header("Location: fatture_main.php");
        exit();
    } else {
        // Gestisco eventuali errori durante l'inserimento dei dati
        echo "Si è verificato un errore durante l'inserimento dei dati.";
    }
} else {
    // Gestisco il caso in cui i dati POST non siano stati inviati
    echo "Dati mancanti.";
}
?>
