<?php
include "../libreria.php";

$conn = connetti_db();

if (isset($_POST['FatturaId'], $_POST['NumFattura'], $_POST['Importo'], $_POST['dataFattura'])) {
    // Ottengo i dati POST
    $IdFattura = $_POST['FatturaId'];
    $NumFattura = $_POST['NumFattura'];
    $Importo = $_POST['Importo'];
    $DataFattura = $_POST['dataFattura'];

    // Preparazione dello statement SQL
    $sql = "UPDATE fatture SET NumFattura = ?, Importo = ?, DataFattura = ? WHERE IdFattura = ?";
    $stmt = mysqli_prepare($conn, $sql);

    // Associo i parametri
    mysqli_stmt_bind_param($stmt, "idsi", $NumFattura, $Importo, $DataFattura, $IdFattura);

    // Eseguo lo statement
    mysqli_stmt_execute($stmt);
}

header("Location: fatture_main.php");
exit();
?>
