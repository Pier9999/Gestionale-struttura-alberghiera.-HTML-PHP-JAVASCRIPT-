
document.addEventListener("DOMContentLoaded", function() {
    // Funzione per trovare l'elemento PrenotazioneId quando viene caricato
    function handlePrenotazioneId() {
        var prenotazioneIdElement = document.getElementById("PrenotazioneId");
        if (prenotazioneIdElement) {
            var prenotazioneId = prenotazioneIdElement.value;
            if (prenotazioneId) {
                fetch("get_importo.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    body: "PrenotazioneId=" + prenotazioneId
                })
                .then(response => response.json())
                .then(data => {
                    document.getElementById("Importo").value = data.totale;
                })
                .catch(error => console.error("Errore:", error));
            }
        }
    }

    // Usa MutationObserver per osservare modifiche nel DOM
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            handlePrenotazioneId();
        });
    });

    // Osserva tutto il body per modifiche
    observer.observe(document.body, { childList: true, subtree: true });
    
    // Verifica iniziale se l'elemento è già presente
    handlePrenotazioneId();
});
