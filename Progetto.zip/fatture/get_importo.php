<?php
include_once "../libreria.php"; // Connessione al database
$conn = connetti_db();

$prenotazioneId = $_POST['PrenotazioneId'];

if ($prenotazioneId) {
    // Prima query: Ottengo il Prezzo dalla tabella prenotazioni
    $sql1 = "SELECT Prezzo FROM prenotazioni WHERE NumPrenotazione = ?";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->bind_param("i", $prenotazioneId);
    $stmt1->execute();
    $result1 = $stmt1->get_result();
    $row1 = $result1->fetch_assoc();
    $prezzo = $row1['Prezzo'] ?? 0; // Se il risultato è nullo, imposto a 0
    
    // Chiudi il primo statement
    $stmt1->close();

    // Seconda query: Sommo l'importo delle spese dalla tabella spese
    $sql2 = "SELECT IFNULL(SUM(Importo), 0) AS totale_spese FROM spese WHERE PrenotazioneId = ?";
    $stmt2 = $conn->prepare($sql2);
    $stmt2->bind_param("i", $prenotazioneId);
    $stmt2->execute();
    $result2 = $stmt2->get_result();
    $row2 = $result2->fetch_assoc();
    $totale_spese = $row2['totale_spese'] ?? 0; // Se il risultato è nullo, imposto a 0
    
    // Chiudo il secondo statement
    $stmt2->close();

    // Somma dei risultati
    $totale = $prezzo + $totale_spese;
    
    // Restituisco il risultato in formato JSON
    echo json_encode(['totale' => $totale]);

    // Chiudo la connessione al database
    $conn->close();
}
?>
