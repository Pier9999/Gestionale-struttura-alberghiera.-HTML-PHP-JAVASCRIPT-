document.addEventListener("DOMContentLoaded", function () {
    const contentContainer = document.getElementById("contentContainer");
    const btnInserisci = document.getElementById("btnIns");
    const btnModifica = document.getElementById("btnMod");
    const btnElimina = document.getElementById("btnEl");

    // Codice per gestire il click sui bottoni e il caricamento del contenuto HTML
    btnInserisci.addEventListener('click', function () {
        loadContent('fattura_inserimento.html', function () {
            popolaFormInserisci();
        });
    });

    btnModifica.addEventListener("click", function () {
        loadContent("fattura_modifica.html", function () {

        });
    });

    btnElimina.addEventListener("click", function () {
        loadContent("fattura_elimina.html", function () {

        });
    });


    function loadContent(filename, callback) {
        fetch(filename)
            .then(response => response.text())
            .then(data => {
                contentContainer.innerHTML = data;
                callback();
            })
            .catch(error => {
                console.error('Si è verificato un errore durante il caricamento del contenuto:', error);
            });
    }



    // Codice per gestire il click sulle righe della tabella e il riempimento del form
    var table = document.getElementById("TabellaFatture");
    var rows = table.getElementsByTagName("tr");

    for (var i = 0; i < rows.length; i++) {
        rows[i].addEventListener("click", function () {
            var cells = this.getElementsByTagName("td");
            var rowData = [];
            for (var j = 0; j < cells.length; j++) {
                rowData.push(cells[j].innerHTML);
            }
            fillForm(rowData);
        });
    }

});

// popolo il form
function fillForm(rowData) {
    var form = document.getElementById('myForm');
    if (form) {

        var FatturaId = form.querySelector('#FatturaId');
        var NumFattura = form.querySelector('#NumFattura');
        var DataFattura = form.querySelector('#dataFattura');
        var ImportoFattura = form.querySelector('#Importo');

        FatturaId.value = rowData[0];
        NumFattura.value = rowData[1];
        DataFattura.value = rowData[2];
        ImportoFattura.value = rowData[3];
    }
}


function convertiFormatoData(data) {
    // Divido la data in parti usando il separatore '/'
    var partiData = data.split('-');

    // Estraggo giorno, mese e anno
    var anno = partiData[0];
    var mese = partiData[1];
    var giorno = partiData[2];

    // Costruisco la data nel nuovo formato
    var nuovaData = giorno + '-' + mese + '-' + anno;


    return nuovaData;
}


// inserisco Cognome e Nome nell'intestazione
document.addEventListener("DOMContentLoaded", function () {
    // Recupero le variabili dal localStorage
    var rigaHTML = localStorage.getItem("rigaDati");

    var Nome = rigaHTML.split(", ")[3] + " " + rigaHTML.split(", ")[2];
    
    var Arrivo = rigaHTML.split(", ")[5];
    var Partenza = rigaHTML.split(", ")[6];

    Arrivo = convertiFormatoData(Arrivo);
    Partenza = convertiFormatoData(Partenza);
    // Seleziono l'elemento <h2> per la sezione spese
    var speseTitle = document.getElementById("intestazione");

    // Aggiorno il contenuto dell'elemento <h2> con le variabili
    if (Nome) {
        speseTitle.textContent = "Fattura per il Sig. " + Nome + " dal " + Arrivo + " al " + Partenza;
    }
});

function popolaFormInserisci() {
    var rigaHTML = localStorage.getItem("rigaDati");
    if (rigaHTML) {
        // Popolo il campo con id "IdPrenotazione" nel form specificato con il valore memorizzato
        var form = document.getElementById('FormInserisci');
        if (form) {
            var idPrenotazioneInput = form.querySelector('#PrenotazioneId');
            if (idPrenotazioneInput) {
                idPrenotazioneInput.value = rigaHTML.split(", ")[1];
            } else {
                console.error('Campo "PrenotazioneId" non trovato nel form.');
            }
        } else {
            console.error('Form con ID specificato non trovato.');
        }
    } else {
        console.error('Nessun dato trovato nel localStorage.');
    }
}

function conferma() {
    // Mostro la finestra di conferma
    var conferma = confirm("Sei sicuro di eliminare la fattura?");

    // Se l'utente conferma, eseguio il submit del form
    if (conferma) {
        return true; // Invio il form
    } else {
        
        console.log("Invio del modulo annullato.");
        return false;
    }
}


// leggo dal localStorage eseguo una query e popolo la tabella e aggiungo un listener ad ogni riga

document.addEventListener("DOMContentLoaded", function () {
    var rigaHTML = localStorage.getItem("rigaDati");

    if (rigaHTML !== null) {

        var IdPrenotazione = rigaHTML.split(", ")[1];

        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'queryFatture.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    console.log('Risposta ricevuta: ' + xhr.responseText);
                    var data = JSON.parse(xhr.responseText);
                    var tableBody = document.getElementById('tableBody');

                    // Pulisco la tabella prima di riempirla di nuovo
                    tableBody.innerHTML = '';

                    if (data.length > 0) {
                        data.forEach(row => {
                            var newRow = document.createElement('tr');
                            Object.values(row).forEach(value => {
                                var newCell = document.createElement('td');
                                newCell.textContent = value;
                                newRow.appendChild(newCell);
                            });
                            tableBody.appendChild(newRow);
                        });

                        // Aggiungo gli event listener alle righe
                        addRowListeners();
                        btnIns.disabled = true;
                    } else {
                        // Se non ci sono dati, scrivo nel log
                        console.log('Nessun dato trovato.');
                    }
                } else {
                    console.error('Si è verificato un errore:', xhr.status);
                }
            }
        };

        var params = 'IdPrenotazione=' + IdPrenotazione;
        xhr.send(params);
    } else {
        alert("No data found in localStorage under 'rigaDati'");
    }
});

// Aggiungo dei Listener ad ogni riga della tabella
function addRowListeners() {
    var rows = document.querySelectorAll('#tableBody tr');  // Seleziono tutte le righe della tabella
    rows.forEach(row => {
        row.addEventListener('click', function () {
            var cells = this.getElementsByTagName('td');
            var rowData = [];
            for (var j = 0; j < cells.length; j++) {
                rowData.push(cells[j].innerHTML);
            }
            fillForm(rowData); // Passo il secondo valore della riga
        });
    });
}