<?php
include_once "../libreria.php";

// Verifico se è stata ricevuta una richiesta POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifico se è stato ricevuto il parametro IdPrenotazione
    if (isset($_POST['IdPrenotazione']) && !empty($_POST['IdPrenotazione'])) {
        // Preparazione della query con istruzioni preparate
        $IdPrenotazione = $_POST['IdPrenotazione'];
        $QuerySpese = "SELECT IdFattura, NumFattura, DataFattura, Importo FROM fatture WHERE PrenotazioneId = ?";
        
        // Connessione al database e esecuzione della query con istruzioni preparate
        $conn = connetti_db();
        $stmt = $conn->prepare($QuerySpese);
        $stmt->bind_param("i", $IdPrenotazione);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res && $res->num_rows > 0) {
            // Array per memorizzare i risultati della query
            $resultArray = array();
            while ($row = $res->fetch_assoc()) {
                // Aggiungo ogni riga alla matrice dei risultati
                $resultArray[] = $row;
            }
            // Converto l'array in formato JSON e restituisco i dati
            echo json_encode($resultArray);
        } else {
            // Nessun risultato trovato o errore nella query
            echo json_encode([]); // Invio un array vuoto in formato JSON
        }
        $stmt->close();
        $conn->close();
    } else {
        // Parametro IdPrenotazione non ricevuto o vuoto
        echo json_encode([]); // Invio un array vuoto in formato JSON
    }
} else {
    // Richiesta non POST
    echo json_encode([]); // Invio un array vuoto in formato JSON
}
?>
