<?php

session_start();

include_once "libreria.php";
// Connessione al database
$conn = connetti_db();

if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

$login = sanitize_input($_POST['username']);
$password_plain = sanitize_input($_POST['password']);

// Recupero l'hash della password dal database
$sql = $conn->prepare("SELECT password FROM utenti WHERE login = ?");
$sql->bind_param("s", $login);
$sql->execute();
$result = $sql->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $password_hash = $row['password'];

    // Verifico la password
    if (password_verify($password_plain, $password_hash)) {
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $login;
        header("Location: principale/principale.php");
        exit();
    } else {
        header("Location: erroreCredenziali.html");
        exit();
    }
} else {
    header("Location: erroreCredenziali.html");
    exit();
}

$sql->close();
$conn->close();
?>