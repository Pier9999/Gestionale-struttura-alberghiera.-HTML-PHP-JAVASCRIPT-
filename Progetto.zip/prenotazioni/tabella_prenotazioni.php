<h5>Tabella prenotazioni</h5>
<div class="table responsive">
    <table id="TabellaPrenotazioni" class="table table-bordered border-primary">
        <thead>
            <th>Id C.</th>
            <th>Id P.</th>
            <th>Cognome</th>
            <th>Nome</th>
            <th>Camera</th>
            <th>Check-In</th>
            <th>Check-Out</th>
            <th>Stato</th>
        </thead>
        <tbody id="tableBody">

        
        </tbody>
    </table>
</div>

<div class="row justify-content-center text-center">
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnIns" name="btnInserisci">Nuova</button>
    </div>
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnMod" name="btnModifica">Modifica</button>
    </div>
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnEl" name="btnElimina">Cancella</button>
    </div>
</div>
<br>
<div class="row justify-content-center text-center">
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-success" id="inviaRigaSpese" name="inviaRigaSpese">SPESE</button>
    </div>
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-success" id="inviaRigaFatture" name="inviaRigaFatture">FATTURE</button>
    </div>
</div>