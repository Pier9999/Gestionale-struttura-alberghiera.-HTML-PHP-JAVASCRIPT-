
async function disponibilita(formData, flag) {
    const nomeCamera = formData.get('NomeCamera');
    const CodPrenotazione = formData.get('CodPrenotazione');
    const dataArrivo = formData.get('dataArrivo');
    const dataPartenza = formData.get('dataPartenza');
    let numPrenotazioni = 0; // Inizializzo la variabile numPrenotazione

    if (dataArrivo == "" || dataPartenza == "") {
        alert("Verificare le date");
        return false;
    }

    const datiForm = {
        CodPrenotazione: CodPrenotazione,
        dataArrivo: dataArrivo,
        dataPartenza: dataPartenza,
        nomeCamera: nomeCamera
    };

    const fileQuery = flag === 0 ? 'ContrInserisci.php' : 'ContrModifica.php';

    try {
        const response = await fetch(fileQuery, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(datiForm),
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();

        // Assegno il valore a numPrenotazione in base alla risposta del server
        numPrenotazioni = data.numPrenotazioni;

        return numPrenotazioni == 0; // Se il valore è 0 ritorna true altrimenti false

    } catch (error) {
        console.error('Errore:', error);
        return false; // Aggiunto un ritorno false nel caso di errori
    }
}
