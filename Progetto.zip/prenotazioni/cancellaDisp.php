<?php
// Verifica se è stata inviata una richiesta POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Ottiengo i dati inviati tramite JSON
    $json_data = file_get_contents("php://input");
    
    // Decodifica i dati JSON in un array associativo
    $data = json_decode($json_data, true);
    
    // Verifico se i dati sono stati decodificati correttamente
    if ($data === null) {
        // Gestisco eventuali errori di decodifica JSON
        die("Errore nella decodifica JSON dei dati inviati");
    }
    
    // Verifico se è stato fornito il parametro idPre
    if (!isset($data['idPre'])) {
        die("Parametro idPre non fornito");
    }
    
    // Connessione al database
    $conn = connetti_db();

    // Verifico la connessione al database
    if (!$conn) {
        die("Connessione al database fallita: " . mysqli_connect_error());
    }
    
    // Sanitizzazione del parametro idPre per evitare SQL injection
    $idPre = mysqli_real_escape_string($conn, $data['idPre']);

    // Query per eliminare le righe dalla tabella disponibilitacamere con il CodPrenotazione fornito
    $query = "DELETE FROM disponibilitacamere WHERE CodPrenotazione = '$idPre'";

    // Esecuzione della query
    if (mysqli_query($conn, $query)) {
        // Se l'eliminazione è avvenuta con successo, restituisce una risposta JSON
        echo json_encode(array("success" => true));
    } else {
        // Se si verifica un errore durante l'eliminazione, restituisci un messaggio di errore JSON
        echo json_encode(array("success" => false, "error" => "Errore durante l'eliminazione"));
    }

    // Chiusura della connessione al database
    mysqli_close($conn);
} else {
    // Se la richiesta non è una richiesta POST, restituisci un messaggio di errore
    http_response_code(405); // Metodo non consentito
    echo "Metodo non consentito";
}
?>