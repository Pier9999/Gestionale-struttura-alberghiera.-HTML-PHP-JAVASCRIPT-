<h3>Nuova prenotazioneinserimento:</h3>
<div id="selectedRowData"></div>
<form class="needs-validation" id="myForm" action="inserisci_prenotazione.php" method="POST">
<?php
include "formPrenotazione.php";
?>
<br>  
<div>
    <button type="submit" class="btn btn-primary">Inserisci</button>
</div>
</form>