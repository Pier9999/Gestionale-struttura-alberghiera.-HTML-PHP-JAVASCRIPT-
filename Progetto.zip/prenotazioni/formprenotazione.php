<?php
// Recupero il valore di CodCliente dal POST
$CodCliente = $_POST['CodCliente'] ?? null;
$NumPrenotazione = $POST['CodPre'] ?? null;
?>
<div>
    <div class="row">
        <div>
            <input type="hidden" name="CodPrenotazione" id="CodPrenotazione">
        </div>
        <div>
            <input type="hidden" name="CodCliente" id="CodCliente" value="<?php echo $CodCliente; ?>">
        </div>

        <div class="col-md-6">
            <div class="form-group mt-1">
                <div class="select-wrapper">
                    <label for="defaultSelect">Nome camera</label>
                    <select id="NomeCamera" name="NomeCamera">
                        <?php
                        include "../libreria.php";
                        $query = "SELECT NomeCamera FROM camere;";
                        $result = eseguiQuery($query);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row['NomeCamera'] . "'>" . $row['NomeCamera'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="form-group mt-1">
                <label class="active" for="dateStandard">Data conferma</label>
                <input type="date" id="dataPrenotazione" name="dataPrenotazione">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group mt-1">
                <label class="active" for="dateStandard">Data arrivo</label>
                <input type="date" id="dataArrivo" name="dataArrivo">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group mt-1">
                <label class="active" for="dateStandard">Data partenza</label>
                <input type="date" id="dataPartenza" name="dataPartenza">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group mt-1">
                <label for="inputNumber3" class="input-number-label active">Importo</label>
                <div class="input-group input-number input-number-currency">
                    <span class="input-group-text fw-semibold">€</span>
                    <input type="number" class="form-control" data-bs-input id="Prezzo" name="Prezzo" step="any" min="0" />
                    <span class="input-group-text align-buttons flex-column">
                    </span>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group mt-1">
                <label for="inputNumber3" class="input-number-label active">Acconto</label>
                <div class="input-group input-number input-number-currency">
                    <span class="input-group-text fw-semibold">€</span>
                    <input type="number" class="form-control" data-bs-input id="Acconto" name="Acconto" step="any" min="0" />
                    <span class="input-group-text align-buttons flex-column">
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group mt-1">
                <label for="inputNumber2" class="input-number-label active">Numero ospiti</label>
                <div class="input-group input-number">
                    <input type="number" class="form-control" data-bs-input id="NumOspiti" name="NumOspiti" value="0" min="1" max="4" step="1" />
                </div>

            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group mt-1">
                <label for="defaultSelect">Codice prenotazione</label>
                <input type=" text" class="form-control text-right" id="CodPre" name="CodPre" placeholder="Codice prenotazione">
            </div>
        </div>
    </div>
    <div class="row">
    <div class="col-md-6">
            <div class="form-group mt-1">
                <div class="select-wrapper">
                    <label for="defaultSelect">Nome agenzia</label>
                    <select id="Agenzia" name="Agenzia">
                        <?php
                       
                        $query = "SELECT NomeAgenzia FROM agenzie;";
                        $result = eseguiQuery($query);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row['NomeAgenzia'] . "'>" . $row['NomeAgenzia'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group mt-2">
                <div class="select-wrapper">
                    <label for="defaultSelect">Stato prenotazione</label>
                    <select id="StatoPrenotazione" name="StatoPrenotazione">
                        <option selected="" value="Confermata">Confermata</option>

                    </select>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group mt-1">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="RadioPagato" id="RadioPagato">
                    <label class="form-check-label" for="flexRadioDefault1">
                        Saldato
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="RadioNonPagato" id="RadioNonPagato" checked>
                    <label class="form-check-label" for="flexRadioDefault2">
                        Non saldato
                    </label>
                </div>
            </div>
        </div>


    </div>
    <div class="row">
        <div class="form-group mt-1">
            <span class="input-group-text">Note</span>
            <textarea class="form-control" aria-label="With textarea" id="NotaPre" name="NotaPre"></textarea>
        </div>
    </div>
</div>