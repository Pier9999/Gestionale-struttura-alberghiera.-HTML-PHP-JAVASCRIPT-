<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// Recupero il corpo della richiesta JSON
$json_data = file_get_contents("php://input");

// Decodifico il JSON in un array associativo
$data = json_decode($json_data, true);

// Verifico se i dati sono stati decodificati correttamente
if ($data === null) {
    die(json_encode(["error" => "Errore nella decodifica JSON dei dati inviati"]));
}

// Verifico che i campi necessari siano presenti
$NomeCamera = $data['nomeCamera'] ?? null;
$NumOspiti = $data['numOspiti'] ?? null;

if ($NomeCamera === null || $NumOspiti === null) {
    die(json_encode(["error" => "nomeCamera e numOspiti sono richiesti"]));
}

// Connessione al database
include "../libreria.php";
$conn = connetti_db();

// Controllo della connessione
if ($conn->connect_error) {
    die(json_encode(["error" => "Connessione al database fallita: " . $conn->connect_error]));
}

// Preparazione della query SQL per prevenire SQL Injection
$stmt = $conn->prepare("SELECT NumPostiLetto FROM camere WHERE NomeCamera = ?");
if (!$stmt) {
    die(json_encode(["error" => "Errore nella preparazione della query: " . $conn->error]));
}

// Bind dei parametri alla query preparata
$stmt->bind_param("s", $NomeCamera);

// Esecuzione della query
if (!$stmt->execute()) {
    die(json_encode(["error" => "Errore nell'esecuzione della query: " . $stmt->error]));
}

// Ottengo i risultati dalla query eseguita
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row === null) {
    die(json_encode(["error" => "Camera non trovata"]));
}

$PostiLetto = (int) $row['NumPostiLetto'];

// Chiusura dello statement
$stmt->close();

// Chiusura della connessione
$conn->close();

// Ritorno dei dati in formato JSON
$response = ['success' => $PostiLetto >= $NumOspiti];
echo json_encode($response);
?>
