
// riempio la tabella dinamicamente
document.addEventListener("DOMContentLoaded", function () {
    var rigaHTML = localStorage.getItem("rigaDati");

    if (rigaHTML !== null) {
        var IdCliente = rigaHTML.split(", ")[0];

        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'queryPrenotazioni.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    console.log('Risposta ricevuta: ' + xhr.responseText);
                    var data = JSON.parse(xhr.responseText);
                    var tableBody = document.getElementById('tableBody');

                    // Pulisco la tabella prima di riempirla di nuovo
                    tableBody.innerHTML = '';

                    data.forEach(row => {
                        var newRow = document.createElement('tr');
                        Object.values(row).forEach(value => {
                            var newCell = document.createElement('td');
                            newCell.textContent = value;
                            newRow.appendChild(newCell);
                        });
                        tableBody.appendChild(newRow);
                    });

                    // Aggiungo gli event listener alle righe
                    addRowListeners();
                } else {
                    console.error('Si è verificato un errore:', xhr.status);
                }
            }
        };

        var params = 'IdCliente=' + IdCliente;
        xhr.send(params);
    }
    else {
        alert("No data found in localStorage under 'rigaDati'");
    }
});

// Aggiungo dei Listener ad ogni riga della tabella
function addRowListeners() {
    var rows = document.querySelectorAll('#tableBody tr');  // Seleziono tutte le righe della tabella
    rows.forEach(row => {
        row.addEventListener('click', function() {
            var cells = this.getElementsByTagName('td');
            var rowData = [];
            for (var j = 0; j < cells.length; j++) {
                rowData.push(cells[j].innerHTML);
            }
            fillForm(rowData[1]); // Passo il secondo valore della riga
        });
    });
}
