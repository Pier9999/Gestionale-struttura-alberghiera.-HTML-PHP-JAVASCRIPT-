<?php
include "../libreria.php";

$CodPrenotazione = sanitize_input($_POST['CodPrenotazione']);

// Creazione della connessione
$conn = connetti_db();

// Controllo della connessione
if ($conn->connect_error) {
    die("Connessione al database fallita: " . $conn->connect_error);
}
$conn->begin_transaction();

$successo = false; // Inizializzo la variabile booleana

try {
    // Prima query per eliminare dalle disponibilità
    $sqlEliminaDisponibilita = "DELETE FROM disponibilitacamere WHERE CodPrenotazione = ?";
    $stmtEliminaDisponibilita = $conn->prepare($sqlEliminaDisponibilita);
    $stmtEliminaDisponibilita->bind_param("s", $CodPrenotazione);
    $stmtEliminaDisponibilita->execute();

    // Seconda query per eliminare dalle prenotazioni
    $sqlEliminaPrenotazione = "DELETE FROM prenotazioni WHERE NumPrenotazione = ?";
    $stmtEliminaPrenotazione = $conn->prepare($sqlEliminaPrenotazione);
    $stmtEliminaPrenotazione->bind_param("s", $CodPrenotazione);
    $stmtEliminaPrenotazione->execute();

    // Confermo la transazione
    $conn->commit();

    $successo = true; // Imposto la variabile a true se le eliminazioni sono avvenute con successo
} catch (Exception $e) {
    // Se si verifica un errore, annullo la transazione
    $conn->rollback();
    echo "Si è verificato un errore durante l'eliminazione: " . $e->getMessage();
}
// Chiudo gli statement
$stmtEliminaDisponibilita->close();
$stmtEliminaPrenotazione->close();

// Restituisco il valore booleano che indica se le eliminazioni sono avvenute con successo, in formato JSON
echo json_encode(['success' => $successo]);

header("Location: prenotazioni_main.php");
exit();
?>