<?php
header("Access-Control-Allow-Origin: *");

include_once "libreria.php";

// Recupero il corpo della richiesta JSON
$json_data = file_get_contents("php://input");

// Decodifico il JSON in un array associativo
$data = json_decode($json_data, true);


// Verifico se i dati sono stati decodificati correttamente
if ($data === null) {
    // Gestisco eventuali errori di decodifica JSON
    die("Errore nella decodifica JSON dei dati inviati");
}

// Connessione al database
$conn = connetti_db();

// Controllo della connessione
if (!$conn) {
    die("Connessione al database fallita: " . mysqli_connect_error());
}

// Estraggo i dati dalle chiavi dell'array
$nomeCamera = $data['nomeCamera'] ?? null;
$idPre = $data['idPre'] ?? null;
$dataArrivo = new DateTime($data['dataArrivo'] ?? null);
$dataPartenza = new DateTime($data['dataPartenza'] ?? null);
$flag = $data['flag'] ?? null;

$differenza = $dataArrivo->diff($dataPartenza);
$numGiorni = $differenza->days;

if($flag){
    $QueryMaxPren = "SELECT MAX(CodPrenotazione) As maxNum FROM prenotazioni;";
    $idPre = massimo($QueryMaxPren);
    
    $result = eseguiQuery($QueryMaxPren);
    if ($result->num_rows > 0) {
        // Ottengo la riga risultante come array associativo
        $row = $result->fetch_assoc();
        // Ottengo il valore massimo di CodClienti
        $maxCod = $row["maxNum"];
        // Inserisco il valore massimo in una variabile PHP
        $idPre = intval($maxCod); // Mi assicuro che il valore sia trattato come intero
    }
    
}

$inserimentiRiusciti = true;
$stmt = $conn->prepare("INSERT INTO disponibilitacamere (CodPrenotazione, Data, TipoCamera) VALUES (?, ?, ?)");


for ($i = 0; $i < $numGiorni; $i++){
    $dataFormatted = $dataArrivo->format('Y-m-d');
    $stmt->bind_param("iss", $idPre, $dataFormatted, $nomeCamera);
    if (!$stmt->execute()) {
        $inserimentiRiusciti = false;
        break;
    }
    $dataArrivo->modify('+ 1 day');
}

// Chiusura della connessione
mysqli_close($conn);

// Preparo e invio la risposta JSON
$response = [
    'success' => $inserimentiRiusciti,
    'message' => $inserimentiRiusciti ? "Inserimenti completati con successo." : "Errore durante l'inserimento dei dati."
];

echo json_encode($response);
?>