<?php
header("Access-Control-Allow-Origin: *");

// Recupero il corpo della richiesta JSON
$json_data = file_get_contents("php://input");

// Decodifico il JSON in un array associativo
$data = json_decode($json_data, true);

// Verifico se i dati sono stati decodificati correttamente
if ($data === null) {
    // Gestisco eventuali errori di decodifica JSON
    die("Errore nella decodifica JSON dei dati inviati");
}

include_once "../libreria.php";

// Connessione al database
$conn = connetti_db();

// Controllo della connessione
if ($conn->connect_error) {
    die("Connessione al database fallita: " . $conn->connect_error);
}

// Preparazione della query SQL per prevenire SQL Injection
$stmt = $conn->prepare("SELECT COUNT(*) AS numPrenotazioni FROM disponibilitacamere WHERE TipoCamera = ? AND Data >= ? AND Data < ? AND CodPrenotazione != ?");

// Verifico se la preparazione della query è riuscita
if (!$stmt) {
    die("Errore nella preparazione della query: " . $conn->error);
}

// Estraggo i dati dalle chiavi dell'array
$nomeCamera = $data['nomeCamera'] ?? null;
$dataArrivo = $data['dataArrivo'] ?? null;
$dataPartenza = $data['dataPartenza'] ?? null;
$idPre = $data['CodPrenotazione'] ?? null;

// Bind dei parametri alla query preparata
$stmt->bind_param("ssss", $nomeCamera, $dataArrivo, $dataPartenza, $idPre);

// Esecuzione della query
if (!$stmt->execute()) {
    die("Errore nell'esecuzione della query: " . $stmt->error);
}

// Ottengo i risultati dalla query eseguita
$result = $stmt->get_result();
$row = $result->fetch_assoc();

// Estraggo il valore desiderato dall'array
$numPrenotazioni = (int) $row['numPrenotazioni'];

// Creazione dell'array dei dati
$data = array("numPrenotazioni" => $numPrenotazioni);

// Chiusura dello statement
$stmt->close();

// Chiusura della connessione
$conn->close();

// Ritorno dei dati in formato JSON
echo json_encode($data);
?>
