<?php  // inserisciPrenotazione.php
header("Access-Control-Allow-Origin: *");

include "../libreria.php";

// Recupero il corpo della richiesta JSON
$json_data = file_get_contents("php://input");

// Decodifico il JSON in un array associativo
$data = json_decode($json_data, true);


// Verifico se i dati sono stati decodificati correttamente
if ($data === null) {
    // Gestisco eventuali errori di decodifica JSON
    die("Errore nella decodifica JSON dei dati inviati");
}

// Connessione al database
$conn = connetti_db();

// Controllo della connessione
if (!$conn) {
    die("Connessione al database fallita: " . mysqli_connect_error());
}

// Estraggo i dati dalle chiavi dell'array

$codPre = $data['CodPrenotazione'] ?? null;
$dataPrenotazione = $data['dataPrenotazione'] ?? null;
$dataArrivo = $data['dataArrivo'] ?? null;
$dataPartenza = $data['dataPartenza'] ?? null;
$prezzo = $data['Prezzo'] ?? null;
$acconto = $data['Acconto'] ?? null;
$numOspiti = $data['NumOspiti'] ?? null;
$codPreAg = $data['CodPre'] ?? null;
$agenzia = $data['Agenzia'] ?? null;
$statoPrenotazione = $data['StatoPrenotazione'] ?? null;
$percentuale = $data['Percentuale'] ?? null;
$pagato = $data['Pagato'] ?? null;
$notaPre =$data['NotaPre'] ?? null;

$QueryMaxPren = "SELECT MAX(CodClienti) As maxNum FROM prenotazioni;";
$CodCliente = massimo($QueryMaxPren);

$result = eseguiQuery($QueryMaxPren);
if ($result->num_rows > 0) {
    // Ottengo la riga risultante come array associativo
    $row = $result->fetch_assoc();
    // Ottengo il valore massimo di CodClienti
    $maxCod = $row["maxNum"];
    // Inserisco il valore massimo in una variabile PHP
    $CodCliente = intval($maxCod); // Mi assicuro che il valore sia trattato come intero
}

$stmt = $conn->prepare("INSERT INTO prenotazioni (CodCliente, DataPrenotazione, DataCheckin, DataChekout, NumPersone, Prezzo, Acconto, Agenzia, Percentuale, NumPreAgenziaAgenzia, Pagato,
StatoPrenotazione, nota) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");


$stmt->bind_param("isssissssssss", $codCliente, $dataPrenotazione, $dataArrivo, $dataPartenza, $numOspiti, $prezzo, $acconto, $agenzia, $percentuale, 
$codPreAg, $pagato, $statoPrenotazione, $notaPre);
if (!$stmt->execute()) {
    $inserimentiRiusciti = false;
}
else{
    $inserimentiRiusciti = true;
}
// Chiusura della connessione
mysqli_close($conn);

// Preparo e invio la risposta JSON
$response = [
    'success' => $inserimentiRiusciti,
    'message' => $inserimentiRiusciti ? "Inserimenti completati con successo." : "Errore durante l'inserimento dei dati."
];

echo json_encode($response);
?>