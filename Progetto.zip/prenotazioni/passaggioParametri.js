// Stringa HTML da analizzare
        //var rigaHTML = '<td>5</td><td>Bon</td><td>Rossella</td><td>Venezia</td><td>Italia</td><td>BNORSL60H55L736E</td>';
        var rigaHTML = localStorage.getItem("rigaHTML");
        // Creo un elemento div temporaneo per analizzare la riga
        var tempDiv = document.createElement('div');
        tempDiv.innerHTML = '<table><tr>' + rigaHTML + '</tr></table>'; // Aggiungi <table> e <tr> per renderlo HTML valido

        // Recupero i singoli elementi dalla riga
        var celle = tempDiv.querySelectorAll('td');

        // Utilizzo Array.prototype.map per ottenere i contenuti testuali di ciascun <td>
        var dati = Array.from(celle).map(td => td.innerText);

        // Ora dati è un array contenente i valori delle celle
        alert(dati); 
        document.getElementById("idCliente").value = dati[0];
        document.getElementById("clienteLabel").innerText = dati[1] + " " + dati[2];

        
    