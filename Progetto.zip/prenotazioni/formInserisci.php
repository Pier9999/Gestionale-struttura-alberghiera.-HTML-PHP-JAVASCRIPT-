

<h3>Nuova prenotazione inserimento:</h3>
<div class="container">
    <div id="selectedRowData"></div>
    <form class="needs-validation" id="myForm">
        <?php
        include "formprenotazione.php";
        ?>

        <div>
            <button type="submit" class="btn btn-primary" id="btnIns" value="Verifica Disponibilita">Inserisci</button>
        </div>
    </form>
</div>
<script src="disponibilita.js"></script>