<h3>Cancella prenotazione:</h3>
<div class="container">
    <div id="selectedRowData"></div>
    <form class="needs-validation" id="myForm" action="cancellaPre.php" method="POST" onsubmit="return conferma()">
        <?php
        include "formprenotazione.php";
        ?>

        <div>
            <button type="submit" class="btn btn-primary" id="btnEl">Elimina</button>
        </div>
    </form>
</div>
<script>
function confermaCanc() {
    // Visualizzo una finestra di conferma
    var conferma = confirm("Sei sicuro di voler eliminare?");
    
    // Restituisco true se l'utente conferma, altrimenti false
    return conferma;
}
</script>