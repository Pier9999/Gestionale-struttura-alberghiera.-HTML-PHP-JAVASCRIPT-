<?php
include_once "../libreria.php";

// Recupero e sanificazione dei dati dal form
$ClienteId = sanitize_input($_POST['CodCliente']);
$DataPrenotazione = sanitize_input($_POST['dataPrenotazione']);
$DataArrivo = sanitize_input($_POST['dataArrivo']);
$DataPartenza = sanitize_input($_POST['dataPartenza']);
$NumPersone = sanitize_input($_POST['NumOspiti']);
$Prezzo = sanitize_input($_POST['Prezzo']);
$Acconto = sanitize_input($_POST['Acconto']);
$Agenzia = sanitize_input($_POST['Agenzia']);
$NumPrenotazioneAgenzia = sanitize_input($_POST['CodPre']);
$Pagato = isset($_POST['RadioPagato']) ? 1 : 0;
$StatoPrenotazione = sanitize_input($_POST['StatoPrenotazione']);
$Nota = sanitize_input($_POST['NotaPre']);

try {
    // Connessione al database usando mysqli
    $mysqli = new mysqli("localhost", "username", "password", "nome_tuo_database");

    // Controllo della connessione
    if ($mysqli->connect_error) {
        throw new Exception("Connessione al database fallita: " . $mysqli->connect_error);
    }

    // Preparazione della query con Prepared Statements
    $sql = "INSERT INTO prenotazioni (CodCliente, DataPrenotazione, DataCheckin, Datacheckout, NumPersone, Prezzo, Acconto, Agenzia, NumPreAgenzia, Pagato, StatoPrenotazione, nota)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    if ($stmt = $mysqli->prepare($sql)) {
        // Binding dei parametri
        $stmt->bind_param('isssidssisss', $ClienteId, $DataPrenotazione, $DataArrivo, $DataPartenza, $NumPersone, $Prezzo, $Acconto, $Agenzia, $NumPrenotazioneAgenzia, $Pagato, $StatoPrenotazione, $Nota);
        
        // Esecuzione della query
        if ($stmt->execute()) {
            // Redirect alla pagina principale solo se l'inserimento è stato un successo
            header("Location: prenotazioni_main.php");
            exit();
        } else {
            throw new Exception("Errore nell'esecuzione della query: " . $stmt->error);
        }
        
        // Chiusura dello statement
        $stmt->close();
    } else {
        throw new Exception("Errore nella preparazione della query: " . $mysqli->error);
    }
} catch (Exception $e) {
    // Gestione degli errori
    echo "Errore: " . $e->getMessage();
    
} finally {
    // Chiusura della connessione
    $mysqli->close();
}
?>
