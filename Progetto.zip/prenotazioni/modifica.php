<?php
include "../libreria.php";

// Recupero e sanificazione dei dati dal form
$CodCliente = sanitize_input($_POST['CodCliente']);
$CodPrenotazione = sanitize_input($_POST['CodPrenotazione']);

$DataPrenotazione = sanitize_input($_POST['dataPrenotazione']);
$DataArrivo = sanitize_input($_POST['dataArrivo']);
$DataPartenza = sanitize_input($_POST['dataPartenza']);
$NumOspiti = sanitize_input($_POST['NumOspiti']);
$Prezzo = sanitize_input($_POST['Prezzo']);
$Acconto = sanitize_input($_POST['Acconto']);
$Agenzia = sanitize_input($_POST['Agenzia']);
$NumPrenotazioneAgenzia = sanitize_input($_POST['CodPre']);
$radioPagato = sanitize_input($_POST['RadioPagato'] ?? null);
$Pagato = isset($radioPagato) ? 1 : 0;
$StatoPrenotazione = sanitize_input($_POST['StatoPrenotazione']);
$NomeCamera = sanitize_input($_POST['NomeCamera']);
$Nota = sanitize_input($_POST['NotaPre']);

$sqlModificaPrenotazione = "UPDATE prenotazioni SET CodCliente = ?, DataPrenotazione = ?, DataCheckin = ?, DataCheckout = ?,
    NumPersone = ?, Prezzo = ?, Acconto = ?, Agenzia = ?, NumPreAgenzia = ?,
    Pagato = ?, StatoPrenotazione = ?, nota = ? WHERE NumPrenotazione = ?;";

$sqlCancellaDisp = "DELETE FROM disponibilitacamere WHERE CodPrenotazione = ?";

$conn = connetti_db();

$conn->begin_transaction();

$conn = connetti_db();


// Preparo la query
$stmtCancellaDisp = $conn->prepare($sqlCancellaDisp);

// Associo i parametri
$stmtCancellaDisp->bind_param("i", $CodPrenotazione);

if ($stmtCancellaDisp->execute()) {

    if (inserisciCamereOccupate($conn, $CodPrenotazione, $DataArrivo, $DataPartenza, $NomeCamera)) {

        $stmtModificaPrenotazione = $conn->prepare($sqlModificaPrenotazione);
        // Associo i parametri
        $stmtModificaPrenotazione->bind_param("isssisssiissi", $CodCliente, $DataPrenotazione, $DataArrivo, $DataPartenza, $NumOspiti, 
        $Prezzo, $Acconto, $Agenzia, $NumPrenotazioneAgenzia, $Pagato, $StatoPrenotazione, $Nota, $CodPrenotazione);

        $stmtModificaPrenotazione->execute();

        $conn->commit();

        echo json_encode(['success' => true]);
    } else {
        // Rollback della transazione se non è stato possibile ottenere l'ID della prenotazione
        $conn->rollback();
        echo json_encode(['success' => false]);
    }
} else {
    // Rollback della transazione se non è stato possibile ottenere l'ID della prenotazione
    $conn->rollback();
    echo json_encode(['success' => false]);
}

//chiudo lo statement
$stmtCancellaDisp->close();

// Chiudi la connessione
$conn->close();
?>