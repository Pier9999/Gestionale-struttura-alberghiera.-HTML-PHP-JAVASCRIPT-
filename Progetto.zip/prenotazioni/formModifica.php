<h3>Modifica prenotazione:</h3>
<div class="container">
    <div id="selectedRowData"></div>
    <form class="needs-validation" id="myForm">
        <?php
        include "formprenotazione.php";
        ?>

        <div>
            <button type="submit" class="btn btn-primary" id="btnMod">Modifica</button>
        </div>
    </form>
</div>
