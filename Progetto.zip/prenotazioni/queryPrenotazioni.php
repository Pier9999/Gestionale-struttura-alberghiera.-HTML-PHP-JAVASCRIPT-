<?php
// Eseguo la query PHP per ottenere i dati dal database
include_once "../libreria.php";

// Verifico se è stata ricevuta una richiesta POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifico se è stato ricevuto il parametro IdCliente
    if (isset($_POST['IdCliente']) && $_POST['IdCliente'] !== "") {
        // Preparazione della query
        $IdCliente = sanitize_input($_POST['IdCliente']);
        $QueryPrenotazioni = "
    SELECT DISTINCT CodClienti, NumPrenotazione, Cognome, Nome, TipoCamera, DataCheckin, DataCheckout, StatoPrenotazione 
    FROM clienti 
    LEFT JOIN prenotazioni ON CodClienti = CodCliente 
    LEFT JOIN disponibilitacamere ON CodPrenotazione = NumPrenotazione 
    WHERE CodClienti = '" . $IdCliente . "' 
    AND (SELECT COUNT(*) FROM prenotazioni WHERE CodCliente = '" . $IdCliente . "') > 0
    ORDER BY NumPrenotazione, DataCheckin;";

        // Connessione al database e esecuzione della query
        $res = eseguiQuery($QueryPrenotazioni);

        if ($res && $res->num_rows > 0) {
            // Array per memorizzare i risultati della query
            $resultArray = array();
            while ($row = $res->fetch_assoc()) {
                // Aggiungo ogni riga alla matrice dei risultati
                $resultArray[] = $row;
            }
            // Converto l'array in formato JSON
            $jsonData = json_encode($resultArray);
            echo $jsonData;
        } else {
            // Nessun risultato trovato o errore nella query
            echo $jsonData = "[]"; // Invio un array vuoto in formato JSON
        }
    } else {
        // Parametro IdCliente non ricevuto o vuoto
        echo $jsonData = "[]"; // Invio un array vuoto in formato JSON
    }
} else {
    // Richiesta non POST
    echo $jsonData = "[]"; // Invio un array vuoto in formato JSON
}
?>