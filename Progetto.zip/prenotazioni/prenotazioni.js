// prenotazioni.js

document.addEventListener("DOMContentLoaded", function () {
    const contentContainer = document.getElementById("contentContainer");
    const btnInserisci = document.getElementById("btnIns");
    const btnModifica = document.getElementById("btnMod");
    const btnElimina = document.getElementById("btnEl");

    // Codice per gestire il click sui bottoni e il caricamento del contenuto HTML
    btnInserisci.addEventListener("click", function () {
        var rigaDati = localStorage.getItem("rigaDati");

        if (rigaDati) { // Verifico se i dati sono presenti in localStorage
            var codCliente = rigaDati.split(", ")[0]; // Ottieni il valore desiderato dalla riga

            // Utilizzo il valore di codCliente per caricare il form corrispondente
            var formData = new FormData();
            formData.append('CodCliente', codCliente);


            fetch('formInserisci.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.text())
                .then(data => {
                    contentContainer.innerHTML = data;
                    attachFormEvent(0);
                })
                .catch(error => {
                    console.error('Si è verificato un errore durante il caricamento del contenuto:', error);
                });
        } else {
            console.error("Dati della riga non trovati in localStorage.");
        }
    });

    btnModifica.addEventListener("click", function () {
        var rigaDati = localStorage.getItem("rigaDati");

        if (rigaDati) { // Verifico se i dati sono presenti in localStorage
            var codCliente = rigaDati.split(", ")[0]; // Ottengo il valore desiderato dalla riga

            // Utilizzo il valore di codCliente per caricare il form corrispondente
            var formData = new FormData();
            formData.append('CodCliente', codCliente);

            fetch('formModifica.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.text())
                .then(data => {
                    contentContainer.innerHTML = data;
                    attachFormEvent(1);
                })
                .catch(error => {
                    console.error('Si è verificato un errore durante il caricamento del contenuto:', error);
                });
        } else {
            console.error("Dati della riga non trovati in localStorage.");
        }
    });

    btnElimina.addEventListener("click", function () {
        loadContent("formCancella.php", function () {
        });
    });

});

function loadContent(filename, callback) {
    fetch(filename)
        .then(response => response.text())
        .then(data => {
            contentContainer.innerHTML = data;
            callback();
        })
        .catch(error => {
            console.error('Si è verificato un errore durante il caricamento del contenuto:', error);
        });
}

async function prenotaCamera(formData, flag) {

    const filephp = flag === 0 ? 'inserisci.php' : 'modifica.php';

    try {
        const response = await fetch(filephp, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error('Errore nella prenotazione della camera');
        }
        const result = await response.json();
        
        return result.success;  // Assumo che la risposta includa un campo booleano "success"
    } catch (error) {
        console.error('Errore durante la prenotazione:', error);
        return false;
    }
}

// Funzione che controlla la disponibilità della camera
function attachFormEvent(flag) {
    const form = document.getElementById('myForm'); // Id del form
    if (form) {
        form.addEventListener('submit', function (event) {
            event.preventDefault();
            try {
                const formData = new FormData(form);
                disponibilita(formData, flag)
                    .then(isDisponibile => {
                        if (isDisponibile) {
                            controllaCapienzaCamera(formData)
                                .then(isCapienzaSufficiente => {
                                    if (isCapienzaSufficiente) {
                                        alert("Camera disponibile e capienza sufficiente");
                                        // Procedo con la prenotazione
                                        prenotaCamera(formData, flag)
                                            .then(isPrenotata => {
                                                if (isPrenotata) {
                                                    alert("Prenotazione effettuata con successo!");
                                                    window.location.href = "prenotazioni_main.php";
                                                } else {
                                                    alert("Non è stato possibile completare la prenotazione. \n Selezionare una prenotazione dalla tabella a destra");
                                                }
                                            });
                                    } else {
                                        alert("La capienza della camera non è sufficiente.");
                                    }
                                })
                                .catch(error => {
                                    console.error('Errore durante il controllo della capienza:', error.message);
                                    alert('Errore durante il controllo della capienza:', error.message);
                                });
                        } else {
                            alert("Camera non disponibile");
                        }
                    })
                    .catch(error => {
                        console.error('Errore:', error.message);
                        alert('Errore:', error.message);
                    });
            } catch (error) {
                console.error('Errore durante l\'elaborazione del modulo:', error);
                alert('Errore durante l\'elaborazione del modulo:', error);
            }
        });
    } else {
        alert("Form non riconosciuto");
    }
}

async function controllaCapienzaCamera(formData) {
    const nomeCamera = formData.get('NomeCamera');
    const numOspiti = formData.get('NumOspiti');

    if (nomeCamera == "" || numOspiti == "") {
        alert("Dati incompleti");
        return false;
    }

    const datiForm = {
        nomeCamera: nomeCamera,
        numOspiti: numOspiti
    };

    const fileQuery = 'controlloCapienzaCamera.php';

    try {
        const response = await fetch(fileQuery, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(datiForm),
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();

        // Verifico il valore di 'success' dalla risposta del server
        if (data.success) {
            console.log("La capienza della stanza è sufficiente.");
            return true; // La capienza è sufficiente
        } else {
            console.log("La capienza della stanza non è sufficiente.");
            return false; // La capienza non è sufficiente
        }

    } catch (error) {
        console.error('Errore:', error);
        return false; // Restituisco false in caso di errori
    }
}




function fillForm(rowId) {
    // Richiesta AJAX per recuperare i dati della tupla
    var url = "query.php?id=" + rowId;

    // Effettuo una richiesta AJAX per recuperare i dati della tupla
    fetch(url)
        .then(response => response.json()) // Dati restituiti come JSON
        .then(data => {
            // Popolo il modulo con i dati ottenuti dalla risposta
            popolaModulo(data);
        })
        .catch(error => {
            console.error('Si è verificato un errore durante il recupero dei dati della tupla:', error);
        });
}


function popolaModulo(data) {
    var form = document.getElementById('myForm');
    if (form) {
        document.getElementById("CodPrenotazione").value = data.NumPrenotazione;
        
        document.getElementById("CodCliente").value = data.CodCliente;

        document.getElementById("NomeCamera").value = data.TipoCamera;
        document.getElementById("dataPrenotazione").value = data.DataPrenotazione;
        document.getElementById("dataArrivo").value = data.DataCheckin;
        document.getElementById("dataPartenza").value = data.DataCheckout;
        document.getElementById("Prezzo").value = data.Prezzo;
        document.getElementById("Acconto").value = data.Acconto;
        document.getElementById("NumOspiti").value = data.NumPersone;
        document.getElementById("CodPre").value = data.NumPreAgenzia;
        document.getElementById("Agenzia").value = data.Agenzia;
        document.getElementById("StatoPrenotazione").value = data.StatoPrenotazione;
        var pagato = data.Pagato;
        if (pagato == 1) {
            document.getElementById("RadioPagato").checked = true;
            document.getElementById("RadioNonPagato").checked = false;
        } else {
            // Altrimenti, imposto l'opzione "Non saldato" come selezionata
            document.getElementById("RadioPagato").checked = false;
            document.getElementById("RadioNonPagato").checked = true;
        }
        document.getElementById("NotaPre").value = data.nota;
    }
}

document.addEventListener("DOMContentLoaded", function () {
    var table = document.getElementById("TabellaPrenotazioni"); // Seleziono la tabella
    var selectedData = ""; // Variabile per memorizzare i dati selezionati

    table.addEventListener("click", function (event) {
        var riga = event.target.closest("tr"); // Trovo la riga cliccata

        if (riga) {
            var celle = riga.querySelectorAll("td"); // Ottengo tutte le celle (td) della riga cliccata
            var datiCelle = Array.from(celle).map(cell => cell.textContent); // Estraggo il testo di ogni cella

            selectedData = datiCelle.join(", "); // Unisco i dati con una virgola per una facile lettura
            console.log("Dati della riga selezionati:", selectedData);
        }
    });

    var inviaRigaSpeseBtn = document.getElementById("inviaRigaSpese"); // Seleziono il bottone per le spese
    inviaRigaSpeseBtn.addEventListener("click", function () {
        inviaDati(selectedData, "../spese/spese_main.php"); // Chiamo la funzione per gestire l'invio dei dati per le spese
    });

    var inviaRigaFattureBtn = document.getElementById("inviaRigaFatture"); // Seleziono il bottone per le fatture
    inviaRigaFattureBtn.addEventListener("click", function () {
        inviaDati(selectedData, "../fatture/fatture_main.php"); // Chiamo la funzione per gestire l'invio dei dati per le fatture
    });

    function inviaDati(data, destinazione) {
        if (data) { // Controllo se i dati sono stati selezionati

            localStorage.setItem("rigaDati", data); // Memorizzo i dati delle celle in localStorage
            console.log("Dati della riga memorizzati in localStorage:", data);
            // Reindirizzo alla destinazione specificata
            window.location.href = destinazione;
        } else {
            alert("Per favore, seleziona una riga prima di inviare.");
        }
    }
});

function conferma() {
    // Mostoa la finestra di conferma
    var conferma = confirm("Sei sicuro di eliminare la spesa?");

    // Se l'utente conferma, eseguo la sottomissione del form
    if (conferma) {
        return true; // Invio il form
    } else {
        // Altrimenti, non faccio nulla o eseguo altre azioni desiderate
        console.log("Invio del modulo annullato.");
        return false;
    }
}


