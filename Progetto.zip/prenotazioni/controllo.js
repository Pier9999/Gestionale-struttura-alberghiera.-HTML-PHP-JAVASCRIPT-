function controllaData(dataArrivo, dataPartenza, dataPrenotazione) {
    if (dataArrivo == "" || dataPartenza == "" || dataPrenotazione == ""){
        alert("Una o più date non sono state selezionate.");
        return false; // Interrompo l'invio del modulo
    }

    if (dataArrivo > dataPartenza) {
        alert('La data di arrivo non può essere successiva alla data di partenza.');
        return false;
    }
    
     // Controllo se le date sono uguali
     if (dataPartenza.getTime() === dataArrivo.getTime()) {
        alert("Le date di partenza e arrivo non possono essere uguali.");
        return false; // Interrompi l'invio del modulo
    }

    return true;
}

// Evento per il controllo coerenza dei dati inseriti
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('.needs-validation');
    if (form){
        form.addEventListener('submit', async function(event) {
            event.preventDefault(); // Prevengo l'invio standard del form
    
            const dataArrivo = form.querySelector('#dataArrivo').value;
            const dataPartenza = form.querySelector('#dataPartenza').value;
            const dataPrenotazione = form.querySelector('#dataPrenotazione').value;
    
            // Controllo i dati prima dell'invio
            if (!controllaData(dataArrivo, dataPartenza, dataPrenotazione)) {
                return;
            }
            
            // Chiamata alla funzione disponibilita()
            disponibilita(event)
                .then(function(disponibile) {
                    if (disponibile) {
                        form.submit();
                    }
                })
                .catch(function(error) {
                    console.error('Errore:', error);
                    alert('Si è verificato un errore durante la richiesta al server.');
                });
        });
    }    
});