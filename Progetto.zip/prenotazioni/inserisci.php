<?php
include "../libreria.php";

// Recupero e sanificazione dei dati dal form
$CodCliente = sanitize_input($_POST['CodCliente']);

$DataPrenotazione = sanitize_input($_POST['dataPrenotazione']);
$DataArrivo = sanitize_input($_POST['dataArrivo']);
$DataPartenza = sanitize_input($_POST['dataPartenza']);
$NumOspiti = sanitize_input($_POST['NumOspiti']);
$Prezzo = sanitize_input($_POST['Prezzo']);
$Acconto = sanitize_input($_POST['Acconto']);
$Agenzia = sanitize_input($_POST['Agenzia']);
$NumPrenotazioneAgenzia = sanitize_input($_POST['CodPre']);
if (isset($_POST['RadioPagato'])) {
    $RadioPagato = sanitize_input($_POST['RadioPagato']);
    $Pagato = 1; // Oppure assegnare $RadioPagato a $Pagato se necessario
} else {
    $Pagato = 0;
}
$StatoPrenotazione = sanitize_input($_POST['StatoPrenotazione']);
$NomeCamera = sanitize_input($_POST['NomeCamera']);
$Nota = sanitize_input($_POST['NotaPre']);

$sqlPrenotazioni = "INSERT INTO prenotazioni (CodCliente, DataPrenotazione, DataCheckin, Datacheckout, NumPersone, Prezzo, Acconto, Agenzia, NumPreAgenzia, Pagato, StatoPrenotazione, nota) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,  ?, ?, ?)";
$conn = connetti_db();

$conn->begin_transaction();

// Preparo la query
$stmt = $conn->prepare($sqlPrenotazioni);

// Associo i parametri
$stmt->bind_param("isssisssiiss", $CodCliente, $DataPrenotazione, $DataArrivo, $DataPartenza, $NumOspiti, $Prezzo, $Acconto, $Agenzia, $NumPrenotazioneAgenzia, $Pagato, $StatoPrenotazione, $Nota);

if ($stmt->execute()) {
    $MaxCodPrenotazione = $conn->insert_id; // Ottengo l'ID della prenotazione appena inserita

    $numeroGiorni = calcolaDifferenzaGiorni($DataArrivo, $DataPartenza);

    // Esegui il ciclo per inserire le camere occupate
    inserisciCamereOccupate($conn, $MaxCodPrenotazione, $DataArrivo, $DataPartenza, $NomeCamera);

    // Conferma la transazione
    $conn->commit();
    echo json_encode(['success' => true]);
} else {
    // Rollback della transazione se non è stato possibile ottenere l'ID della prenotazione
    $conn->rollback();
    echo json_encode(['success' => false]);
}

//chiudo lo statement
$stmt->close();

// Chiudo la connessione
$conn->close();
?>