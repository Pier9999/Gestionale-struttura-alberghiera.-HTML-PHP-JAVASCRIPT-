<?php
// Creo la connessione
include_once "../libreria.php";
$conn = connetti_db();

// Verifico la connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Ottengo la query inviata dalla richiesta AJAX
$id = sanitize_input($_GET['id']);
$query = "SELECT prenotazioni.*, TipoCamera FROM prenotazioni INNER JOIN disponibilitacamere WHERE NumPrenotazione = CodPrenotazione AND NumPrenotazione = $id";

// Eseguo la query
$result = $conn->query($query);

// Gestisco il risultato 
if ($result->num_rows > 0) {
    // Genero un array associativo dei dati della tupla
    $row = $result->fetch_assoc();

    // Restituisco i dati come JSON
    header('Content-Type: application/json');
    echo json_encode($row);
} else {
    // Se la tupla non è stata trovata, restituisco un messaggio di errore
    echo "Nessuna tupla trovata con l'ID fornito";
}

// Chiudo la connessione al database
$conn->close();
?>
