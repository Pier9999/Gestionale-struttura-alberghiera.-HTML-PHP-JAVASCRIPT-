<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <?php
    $DataIniziale = isset($_GET['data']) ? date('Y-m-d', strtotime($_GET['data'])) : date('Y-m-d');
    echo $DataIniziale;
    ?>
    <div class="container">
        <div class="row justify-content-end">
            <div class="col">
                <button type="button" class="btn btn-outline-primary" id="btnIndietro" name="btnIndietro">Indietro</button>
            </div>
            <div class="col-auto">
                <button type="button" class="btn btn-outline-primary" id="btnAvanti" name="btnAvanti">Avanti</button>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            // Funzione per caricare la nuova data
            function caricareNuovaData(data) {
                // Eseguo una richiesta AJAX per aggiornare solo la parte della pagina interessata
                $.ajax({
                    url: '../aggiorna_data.php', // File PHP per gestire la richiesta
                    type: 'POST',
                    data: { data: data }, // Invio la nuova data al file PHP
                    success: function(response) {
                        // Aggiorno la parte della pagina interessata con la risposta dal server
                        $('#contenuto').html(response);
                    }
                });
            }

            // Gestisco il click sul bottone "Avanti"
            $('#btnAvanti').click(function() {
                // Ottengo la data corrente
                var dataCorrente = "<?php echo $DataIniziale; ?>";
                // Somma 1 giorno alla data corrente
                var nuovaData = new Date(dataCorrente);
                nuovaData.setDate(nuovaData.getDate() + 1);
                // Carico la nuova data
                caricareNuovaData(nuovaData.toISOString().split('T')[0]);
            });

            // Gestisco il click sul bottone "Indietro"
            $('#btnIndietro').click(function() {
                // Ottengo la data corrente
                var dataCorrente = "<?php echo $DataIniziale; ?>";
                // Sottraggo 1 giorno dalla data corrente
                var nuovaData = new Date(dataCorrente);
                nuovaData.setDate(nuovaData.getDate() - 1);
                // Carico la nuova data
                caricareNuovaData(nuovaData.toISOString().split('T')[0]);
            });
        });
    </script>
</body>
</html>
