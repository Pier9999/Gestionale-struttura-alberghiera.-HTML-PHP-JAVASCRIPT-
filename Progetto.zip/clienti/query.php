<?php
// Connessione al database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ca_isabella";

// Creo la connessione
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifico la connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Ottengo la query inviata dalla richiesta AJAX
$id = $_GET['id'];
$query = "SELECT * FROM clienti WHERE CodClienti = $id";

// Eseguo la query
$result = $conn->query($query);

// Gestisco il risultato 
if ($result->num_rows > 0) {
    // Genero un array associativo dei dati della tupla
    $row = $result->fetch_assoc();

    // Restituisco i dati come JSON
    header('Content-Type: application/json');
    echo json_encode($row);
} else {
    // Se la tupla non è stata trovata, restituisco un messaggio di errore
    echo "Nessuna tupla trovata con l'ID fornito";
}

// Chiudo la connessione al database
$conn->close();
?>
