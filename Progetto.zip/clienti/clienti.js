document.addEventListener("DOMContentLoaded", function () {
    const contentContainer = document.getElementById("contentContainer");
    const btnInserisci = document.getElementById("btnIns");
    const btnModifica = document.getElementById("btnMod");
    const btnElimina = document.getElementById("btnEl");

    // Codice per gestire il click sui bottoni e il caricamento del contenuto HTML
    btnInserisci.addEventListener("click", function () {
        loadContent("clienti_inserisci.php", function () {

        });
    });

    btnModifica.addEventListener("click", function () {
        loadContent("clienti_modifica.php", function () {

        });
    });

    btnElimina.addEventListener("click", function () {
        loadContent("clienti_elimina.php", function () {

        });
    });
});

function loadContent(filename, callback) {
    fetch(filename)
        .then(response => response.text())
        .then(data => {
            contentContainer.innerHTML = data;
            callback();
        })
        .catch(error => {
            console.error('Si è verificato un errore durante il caricamento del contenuto:', error);
        });
}

// Codice per gestire il click sulle righe della tabella e il riempimento del form
var table = document.getElementById("myTable");
var rows = table.getElementsByTagName("tr");

for (var i = 0; i < rows.length; i++) {
    rows[i].addEventListener("click", function () {
        var cells = this.getElementsByTagName("td");
        var rowData = [];
        for (var j = 0; j < cells.length; j++) {
            rowData.push(cells[j].innerHTML);
        }
        fillForm(rowData[0]);
    });
}

function fillForm(rowId) {
    // Richiesta AJAX per recuperare i dati della tupla
    var url = "query.php?id=" + rowId;

    // Effettuo una richiesta AJAX per recuperare i dati della tupla
    fetch(url)
        .then(response => response.json()) // Supponendo che i dati siano restituiti come JSON
        .then(data => {
            // Popolo il modulo con i dati ottenuti dalla risposta
            popolaModulo(data);
        })
        .catch(error => {
            console.error('Si è verificato un errore durante il recupero dei dati della tupla:', error);
        });
}


function popolaModulo(data) {
    var form = document.getElementById('myForm');
    if (form) {
        document.getElementById("CodCliente").value = data.CodClienti;
        document.getElementById("Nome").value = data.Nome;
        document.getElementById("Cognome").value = data.Cognome;
        document.getElementById("CodFiscale").value = data.CodFiscale;
        document.getElementById("Indirizzo").value = data.Indirizzo;
        document.getElementById("Citta").value = data.Citta;
        document.getElementById("Cap").value = data.Cap;
        document.getElementById("Stato").value = data.Stato;
        document.getElementById("Telefono").value = data.Telefono;
        document.getElementById("Email").value = data.Email;
        document.getElementById("Nota").value = data.Valutazione;
    }
}

// funzione che filtra tutte le ennuple per cognome
function filterTable() {
    // Variabili
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("searchInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");

    // Loop attraverso tutte le righe della tabella e nascondo quelle che non corrispondono alla query di ricerca
    for (i = 0; i < tr.length; i++) {
        // Modifico questa parte per cercare in una specifica colonna
        td = tr[i].getElementsByTagName("td")[1]; // Indice [1] sta per "Cognome".
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}

document.addEventListener("DOMContentLoaded", function () {
    var table = document.getElementById("myTable"); // Seleziono la tabella
    var selectedData = ""; // Variabile per memorizzare i dati selezionati

    table.addEventListener("click", function (event) {
        var riga = event.target.closest("tr"); // Trovo la riga cliccata

        if (riga) {
            var celle = riga.querySelectorAll("td"); // Ottengo tutte le celle (td) della riga cliccata
            var datiCelle = Array.from(celle).map(cell => cell.textContent); // Estraggo il testo di ogni cella

            selectedData = datiCelle.join(", "); // Unisco i dati con una virgola per una facile lettura
            console.log("Dati della riga selezionati:", selectedData);
        }
    });

    var inviaRigaBtn = document.getElementById("inviaRigaPrenotazione"); // Seleziono il bottone
    inviaRigaBtn.addEventListener("click", function () {
        if (selectedData) { // Controllo se i dati sono stati selezionati

            localStorage.setItem("rigaDati", selectedData); // Memorizzo i dati delle celle in localStorage
            console.log("Dati della riga memorizzati in localStorage:", selectedData);

            window.location.href = "../prenotazioni/prenotazioni_main.php";
        } else {
            alert("Per favore, seleziona una riga prima di inviare.");
        }
    });
});