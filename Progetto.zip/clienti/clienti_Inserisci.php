<h3>Nuovo cliente inserimento:</h3>
<div id="selectedRowData"></div>
<form class="needs-validation" id="Form" action="inserisci_cliente.php" method="POST">
<?php
include "formclienti.php";
?>
    
<div>
    <button type="submit" class="btn btn-primary">Inserisci</button>
</div>
</form>
