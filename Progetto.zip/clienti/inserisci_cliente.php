<?php
include "../libreria.php";

// Recupero e sanitizzazione dei dati dal form
$nome = $_POST['Nome'] ?? '';
$cognome = $_POST['Cognome'] ?? '';
$codFiscale = $_POST['CodFiscale'] ?? '';
$indirizzo = $_POST['Indirizzo'] ?? '';
$citta = $_POST['Citta'] ?? '';
$stato = $_POST['Stato'] ?? '';
$telefono = $_POST['Telefono'] ?? '';
$email = $_POST['Email'] ?? '';
$valutazione = $_POST['Nota'] ?? '';
$cap = $_POST['Cap'] ?? '';

// Apertura della connessione al database
$conn = connetti_db();

if ($conn) {
    // Preparazione della query per l'inserimento
    $stmt = $conn->prepare("INSERT INTO clienti (Nome, Cognome, CodFiscale, Indirizzo, Citta, Stato, Telefono, Email, Valutazione, Cap) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt) {
        // Binding dei parametri
        $stmt->bind_param("ssssssssss", $nome, $cognome, $codFiscale, $indirizzo, $citta, $stato, $telefono, $email, $valutazione, $cap);

        // Esecuzione della query e gestione dell'eventuale errore
        if ($stmt->execute()) {
            // Reindirizzamento in caso di successo
            header("Location: clienti_main.php");
            exit();
        } else {
            // Gestione degli errori di esecuzione
            echo "Errore durante l'esecuzione della query: " . $stmt->error;
        }

        // Chiusura dello statement
        $stmt->close();
    } else {
        // Gestione degli errori di preparazione dello statement
        echo "Errore nella preparazione dello statement: " . $conn->error;
    }

    // Chiusura della connessione
    $conn->close();
} else {
    // Gestione degli errori di connessione
    echo "Errore nella connessione al database";
}
?>
