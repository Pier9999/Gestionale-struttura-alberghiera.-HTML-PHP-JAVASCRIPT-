<h3>Cancellazione clienti:</h3>
<div id="selectedRowData"></div>
<form class="needs-validation" id="myForm" action="elimina_cliente.php" method="POST">
<?php
include "formclienti.php";
?>
    
<div>
    <button type="submit" class="btn btn-primary">Elimina</button>
</div>
</form>