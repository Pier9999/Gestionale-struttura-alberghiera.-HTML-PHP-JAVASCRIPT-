<?php
include "../libreria.php";

// Recupero e sanitizzazione dei dati dal form
$nome = $_POST['Nome'] ?? '';
$cognome = $_POST['Cognome'] ?? '';
$codFiscale = $_POST['CodFiscale'] ?? '';
$indirizzo = $_POST['Indirizzo'] ?? '';
$citta = $_POST['Citta'] ?? '';
$stato = $_POST['Stato'] ?? '';
$telefono = $_POST['Telefono'] ?? '';
$email = $_POST['Email'] ?? '';
$valutazione = $_POST['Nota'] ?? '';
$cap = $_POST['Cap'] ?? '';
$CodClienti = $_POST['CodCliente'] ?? '';

if ($CodClienti) {
    // Apertura della connessione al database
    $conn = connetti_db();

    if ($conn) {
        // Preparazione della query per la cancellazione
        $stmt = $conn->prepare("DELETE FROM clienti WHERE CodClienti = ?");
        if ($stmt) {
            // Binding del parametro
            $stmt->bind_param("i", $CodClienti);

            // Esecuzione della query e gestione dell'eventuale errore
            if ($stmt->execute()) {
                // Reindirizzamento in caso di successo
                header("Location: clienti_main.php");
                exit();
            } else {
                // Gestione degli errori di esecuzione
                echo "Errore durante l'esecuzione della query: " . $stmt->error;
            }

            // Chiusura dello statement
            $stmt->close();
        } else {
            // Gestione degli errori di preparazione dello statement
            echo "Errore nella preparazione dello statement: " . $conn->error;
        }

        // Chiusura della connessione
        $conn->close();
    } else {
        // Gestione degli errori di connessione
        echo "Errore nella connessione al database";
    }
} else {
    // Gestione dei dati mancanti
    echo "ID del cliente non specificato";
}
?>
