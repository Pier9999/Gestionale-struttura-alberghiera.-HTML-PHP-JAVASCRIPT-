<?php
 echo '<br>

<div class="form-group">
    <input type="text" class="form-control" id="Cognome" name="Cognome" placeholder="Cognome del cliente" required>
</div>
<div class="form-group mt-1">
    <input type="text" class="form-control" id="Nome" name="Nome" placeholder="Nome del cliente" required>
</div>

<div class="form-group mt-1">
    <input type="text" class="form-control" id="CodFiscale" name="CodFiscale" placeholder="Codice fiscale o P. Iva">
</div>

<div class="form-group mt-1">
    <input type="text" class="form-control" id="Indirizzo" name="Indirizzo" placeholder="Indirizzo">
</div>
<div class="row">
    <div class="col-md-6">
        <div class="form-group mt-1">
            <input type=" text" class="form-control" id="Citta" name="Citta" placeholder="Città.">
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group mt-1">
            <input type=" text" class="form-control" id="Cap" name="Cap" placeholder="Cap.">
        </div>
    </div>
</div>
<div class="form-group mt-1">
    <input type="text" class="form-control" id="Stato" name="Stato" placeholder="Stato">
</div>
<div class="form-group mt-1">
    <input type="text" class="form-control" id="Telefono" name="Telefono" placeholder="Telefono o cellulare">
</div>
<div class="form-group mt-1">
    <input type="text" class="form-control" id="Email" name="Email" placeholder="Posta elettronica">
</div>
<div class="form-group mt-1">
    <span class="input-group-text">Note</span>
    <textarea class="form-control" aria-label="With textarea" id="Nota" name="Nota"></textarea>
</div>
<div>
    <input type="hidden" name="CodCliente" id="CodCliente">
</div>
<br>'

?>