<?php
session_start();

// Verifico se l'utente è autenticato
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: ../login.html"); // Reindirizzo alla pagina di login se non autenticato
    exit();
}
?>

<!-- prenotazioni_main.php -->
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cà Isabella</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
    <?php
    include "../barranav.html";
    include "../libreria.php";
    ?>

    <div class="container my-5 text-center">
        <h2>Sezione clienti</h2>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6" id="contentContainer">
                    <!-- Contenuto a Sinistra -->

                </div>

                <div class="col-md-6"><br>
                    <!-- Contenuto di dx -->
                    <?php include "tabella_clienti.php"; ?>
                </div>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="clienti.js"></script>
</body>

</html>