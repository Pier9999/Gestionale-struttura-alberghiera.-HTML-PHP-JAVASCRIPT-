<form class="d-flex" role="search">
    <input class="form-control me-2" type="search" id="searchInput" placeholder="Cerca per cognome" onkeyup="filterTable()">
</form>

<h5>Tabella clienti</h5>

<div class="table responsive">
    <table id="myTable" class="table table-bordered border-primary">
        <thead>
            <th>Id Cliente</th>
            <th>Cognome</th>
            <th>Nome</th>
            <th>Città</th>
            <th>Stato</th>
            <th>CodFiscale</th>
        </thead>
        <tbody>

            <?php
            $QueryPrenotazioni = "SELECT CodClienti, Cognome, Nome, Citta, Stato, CodFiscale FROM clienti ORDER BY Cognome;";
            $res = eseguiQuery($QueryPrenotazioni);

            while ($row = $res->fetch_array()) {
                echo '<tr>';
                echo '<td>' . $row['CodClienti'] . '</td>';
                echo '<td>' . $row['Cognome'] . '</td>';
                echo '<td>' . $row['Nome'] . '</td>';
                echo '<td>' . $row['Citta'] . '</td>';
                echo '<td>' . $row['Stato'] . '</td>';
                echo '<td>' . $row['CodFiscale'] . '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>
</div>

<div class="row justify-content-center text-center">
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnIns" name="btnIns">Nuovo</button>
    </div>
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnMod" name="btnMod">Modifica</button>
    </div>
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-primary" id="btnEl" name="btnEl">Cancella</button>
    </div>
</div>
<br>

<div class="row justify-content-center text-center">
    <div class="col-md-4">
        <button type="button" class="btn btn-outline-success" id="inviaRigaPrenotazione" name="inviaRigaPrenotazione">PRENOTAZIONI</button>
    </div>
</div>


