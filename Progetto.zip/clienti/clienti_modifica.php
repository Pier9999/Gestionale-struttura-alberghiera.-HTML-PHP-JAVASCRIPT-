<h3>Cliente selezionato per la modifica:</h3>
<div id="selectedRowData"></div>
<form id="myForm" action="modifica_cliente.php" method="POST">
  <?php
  include "formclienti.php";
  ?>
  <div>
    <button type="submit" class="btn btn-primary">Modifica</button>
  </div>

</form>