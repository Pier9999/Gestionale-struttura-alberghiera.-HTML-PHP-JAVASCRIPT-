<?php

define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'ca_isabella');

function connetti_db()
{
  // Creazione della connessione
  $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
  if ($conn->connect_error) {
    // Gestione dell'errore in modo più dettagliato
    die("Errore di connessione al database: " . $conn->connect_error);
  }
  return $conn;
}

function eseguiQuery($sql)
{
  $conn = connetti_db();

  // Esegui la query
  $result = $conn->query($sql);

  // Gestione degli errori
  if ($result === false) {
    // Restituisci un valore che indica un errore
    return false;
  }

  // Restituisce il risultato della query
  return $result;
}


function CreaIntestazione($DataIniziale, $NumGiorni)
{

  date_default_timezone_set("Europe/Rome");
  $timestamp = strtotime($DataIniziale);

  echo '<th scope="row">' . date("M", $timestamp) . '</th>';

  for ($i = 0; $i < $NumGiorni; $i++) {
    $dataCorrente = strtotime("+" . $i . " days", $timestamp);
    echo '<th>' . date('d-m-y', $dataCorrente) . '</th>';
  }
}

function rigaVuota($NumGiorni)
{
  echo '<tr>';
  for ($i = 0; $i < $NumGiorni + 1; $i++) {
    echo '<td></td>';
  }
  echo '</tr>';
}

function RiempiTabella($DataIniziale, $NumGiorni)
{

  $DataFinale = date('Y-m-d', strtotime("$DataIniziale +$NumGiorni days"));
  $conn = connetti_db();
  $QueryCamere = "SELECT * FROM camere";
  $QueryPrenotazioni = "SELECT Data, TipoCamera, Colore 
                        FROM disponibilitacamere LEFT JOIN prenotazioni 
                        ON CodPrenotazione = NumPrenotazione
                        LEFT JOIN agenzie ON Agenzia = NomeAgenzia
                        WHERE Data BETWEEN ? AND ? ORDER BY disponibilitacamere.TipoCamera, Data;";
  echo '<br><br>';

  $stmtCamere = $conn->prepare($QueryCamere);
  $stmtPrenotazioni = $conn->prepare($QueryPrenotazioni);
  $stmtPrenotazioni->bind_param("ss", $DataIniziale, $DataFinale);

  $stmtCamere->execute();
  $resultCamere = $stmtCamere->get_result();

  $stmtPrenotazioni->execute();
  $resultPrenotazioni = $stmtPrenotazioni->get_result();

  $stmtCamere->close();
  $stmtPrenotazioni->close();
  $conn->close();

  // Array per mappare i nomi dei colori alle classi di Bootstrap
  $colorClasses = [
    'blu' => 'bg-primary',
    'rosso' => 'bg-danger',
    'verde' => 'bg-success',
    'giallo' => 'bg-warning',
    'grigio' => 'bg-secondary',
    'azzurro' => 'bg-info',
    'bianco' => 'bg-light',
    'nero' => 'bg-dark'
  ];

   // Trasforma l'oggetto in array della query prenotazioni
   $arrayPrenotazioni = [];
   while ($row = $resultPrenotazioni->fetch_assoc()) {
       $arrayPrenotazioni[] = $row;
   }

  // il nome della camera e l'agenzia con cui è stata prenotata
    while ($row = $resultCamere->fetch_assoc()) {
        echo '<tr>';
        $temp = $DataIniziale;
        for ($colonna = 0; $colonna < $NumGiorni + 1; $colonna++) {
            if ($colonna == 0) {
                echo '<th scope="row">' . $row['NomeCamera'] . '</th>';
            } else {
                $found = false;
                foreach ($arrayPrenotazioni as $prenotazione) {
                    if ($prenotazione['TipoCamera'] == $row['NomeCamera'] && $prenotazione['Data'] == $temp) {
                        $Colore = strtolower($prenotazione['Colore']);
                        $bgClass = isset($colorClasses[$Colore]) ? $colorClasses[$Colore] : 'table-light';
                        echo "<td class='" . $bgClass . "'></td>";
                        $found = true;
                        break;
                    }
                }
                if (!$found) {
                    echo '<td class="table-light"></td>';
                }
                $temp = date("Y-m-d", strtotime("+1 days", strtotime($temp)));
            }
        }
        echo '</tr>';
    }
}

function OggettoAdArray($result)
{
  $rows = null;
  if ($result->num_rows > 0) {
    // Trasforma l'oggetto mysqli_result in un array
    $rows = $result->fetch_all(MYSQLI_ASSOC);
  }
  return $rows;
}

function risultato()
{
  $query = "SELECT * FROM data;";
  $res = eseguiQuery($query);
  return $res;
}

function inserisci($data)
{
  $query = "INSERT INTO data (DataCorrente) VALUES(' " . $data . " ')";
  $res = eseguiQuery($query);
  return $res;
}


// Funzione per calcolare la differenza in giorni tra due date
function calcolaDifferenzaGiorni($dataInizio, $dataFine)
{
  $date1 = new DateTime($dataInizio);
  $date2 = new DateTime($dataFine);
  $differenza = $date1->diff($date2);
  return $differenza->days;
}

// Funzione per eseguire il ciclo di query per inserire le camere occupate
function inserisciCamereOccupate($conn, $NumPrenotazione, $DataArrivo, $DataPartenza, $NomeCamera)
{
  $date1 = new DateTime($DataArrivo);
  $DataTemp = $date1->format('Y-m-d'); // inizializzata con la data di arrivo
  $numeroGiorni = calcolaDifferenzaGiorni($DataArrivo, $DataPartenza);

  $queryCamere = "INSERT INTO disponibilitacamere (CodPrenotazione, Data, TipoCamera) VALUES (?, ?, ?)";
  $stmtCamere = $conn->prepare($queryCamere);
  $stmtCamere->bind_param("iss", $NumPrenotazione, $DataTemp, $NomeCamera);
  $success = true;

  for ($i = 0; $i < $numeroGiorni; $i++) {
    $DataTemp =  $date1->format('Y-m-d');
    if (!$stmtCamere->execute()) {
      $success = false;
    }
    $date1->modify('+1 day');
  }

  $stmtCamere->close();
  return $success;
}

function massimo($querySql)
{
  $CodCliente = 0;
  $querySql = "SELECT MAX(CodClienti) As maxNum FROM prenotazioni;";
  $result = eseguiQuery($querySql);
  if ($result->num_rows > 0) {
    // Ottengo la riga risultante come array associativo
    $row = $result->fetch_assoc();
    // Ottengo il valore massimo di CodClienti
    $maxCod = $row["maxNum"];
    // Inserisco il valore massimo in una variabile PHP
    $CodCliente = intval($maxCod); // Assicurati che il valore sia trattato come intero
    return $CodCliente;
  }
}

// Funzione per validare e sanificare gli input generici
function sanitize_input($data) {
  return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Funzione per sanificare e validare email
function sanitize_email($email) {
  $email = filter_var(trim($email), FILTER_SANITIZE_EMAIL);
  return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : false;
}

// Funzione per sanificare e validare URL
function sanitize_url($url) {
  $url = filter_var(trim($url), FILTER_SANITIZE_URL);
  return filter_var($url, FILTER_VALIDATE_URL) ? $url : false;
}

// Funzione per sanificare e validare numeri interi
function sanitize_int($int) {
  return filter_var($int, FILTER_VALIDATE_INT);
}



