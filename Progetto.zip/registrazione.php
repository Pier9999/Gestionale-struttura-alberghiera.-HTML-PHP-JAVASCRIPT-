<?php
session_start();
include_once "libreria.php";

// Connessione al database
$conn = connetti_db();

if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Sanifico i dati inviati dal modulo
$login = sanitize_input($_POST['login']);
$password = sanitize_input($_POST['password']);
$conferma_password = sanitize_input($_POST['conferma_password']);

// Verifico se le password coincidono
if ($password !== $conferma_password) {
    header("Location: passwordKo.html");
    exit();
}



// Hash della password
$password_hash = password_hash($password, PASSWORD_DEFAULT);

// Inserisco i dati nel database
$sql = $conn->prepare("INSERT INTO utenti (login, password) VALUES (?, ?)");
$sql->bind_param("ss", $login, $password_hash);

if ($sql->execute()) {
    header("Location: registrazioneOk.html");
    exit();
} else {
    echo "Errore nella registrazione: " . $conn->error;
}

$sql->close();
$conn->close();
?>
