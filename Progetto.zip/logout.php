<?php
include_once "libreria.php";
$deleteData = "TRUNCATE TABLE data";
eseguiQuery($deleteData);

session_start();
session_destroy();
header("Location: index.html"); // Reindirizzo alla pagina di login
exit();
?>