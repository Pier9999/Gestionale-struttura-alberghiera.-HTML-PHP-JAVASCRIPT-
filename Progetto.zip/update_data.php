<?php
include_once "libreria.php";
// Connessione al database
$conn = connetti_db();

// Ottengo la nuova data dal parametro POST
$newData = sanitize_input($_GET['data']);

// Eseguo l'aggiornamento nel database
$stmt = $conn->prepare("UPDATE data SET DataCorrente = ? LIMIT 1"); 
        $stmt->bind_param("s", $newData);
if ($stmt->execute()) {
    echo json_encode(array("success" => "Data aggiornata correttamente"));
} else {
    echo json_encode(array("error" => "Errore durante l'aggiornamento della data nel database"));
}

$stmt->close();

// Chiudo la connessione al database
$conn->close();
?>